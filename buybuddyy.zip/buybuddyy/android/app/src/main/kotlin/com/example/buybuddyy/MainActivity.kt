package com.example.buybuddyy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
