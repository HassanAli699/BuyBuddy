import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:buybuddyy/Widgets/Theme.dart';
import 'package:buybuddyy/Widgets/ThemeProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'Register/welcomeScreen.dart';
import 'package:firebase_core/firebase_core.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(ChangeNotifierProvider(create: (context) => ThemeProvider(), child: const MyApp(),));
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    Provider.of<ThemeProvider>(context).setContext(context);
    return  MaterialApp(
      title: 'Buy Buddy',
      debugShowCheckedModeBanner: false,
      color: AppColors.purpleLight,
      theme: Provider.of<ThemeProvider>(context).getTheme(),
      darkTheme: Provider.of<ThemeProvider>(context).getTheme(),
      home: const WelcomeScreen(),
    );
  }
}
