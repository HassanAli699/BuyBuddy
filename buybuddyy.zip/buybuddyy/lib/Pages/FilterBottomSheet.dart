import 'package:flutter/material.dart';
import '../Widgets/Colors.dart';


class FilterBottomSheet extends StatefulWidget {
  final Map<String, dynamic>? selectedFilters;
  final Function(Map<String, dynamic>) onApplyFilter;

  const FilterBottomSheet({Key? key, required this.onApplyFilter, this.selectedFilters}) : super(key: key);

  @override
  _FilterBottomSheetState createState() => _FilterBottomSheetState();
}

class _FilterBottomSheetState extends State<FilterBottomSheet> {
  List<String> selectedPriceRanges = [];
  List<String> selectedStores = [];
  String? selectedPriceRange;

  Map<String, Map<String, int>> priceRanges = {
    'Rs.0 - Rs.1000': {'min_price': 0, 'max_price': 1000},
    'Rs.1000 - Rs.10,000': {'min_price': 1000, 'max_price': 10000},
    'Rs.10,000 - Rs.50,000': {'min_price': 10000, 'max_price': 50000},
    'Rs.50,000 - Rs.10,0000': {'min_price': 50000, 'max_price': 100000},
  };

  @override
  void initState() {
    super.initState();
    if(widget.selectedFilters != null){
      selectedStores = List<String>.from(widget.selectedFilters?['selectedStores'] ?? []);
      selectedPriceRange = widget.selectedFilters?['selectedPriceRange'];
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.tertiary,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const Center(
              child:  Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
                child: Text(
                  "Apply Filters",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18,),
                ),
              ),
            ),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
              child: Text(
                "Filter By Price",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),

            for (String priceRange in priceRanges.keys)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: CheckboxListTile(
                  title: Text(priceRange),
                  activeColor: AppColors.purpleLight,
                  value: selectedPriceRange == priceRange,
                  onChanged: (bool? value) {
                    setState(() {
                      selectedPriceRange = value! ? priceRange : '';
                    });
                  },
                ),
              ),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Divider(
                color: AppColors.backGroundColor,
              ),
            ),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
              child: Text(
                "Filter By Store",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: CheckboxListTile(
                title: const Text('PriceOye'),
                activeColor: AppColors.purpleLight,
                value: selectedStores.contains('PriceOye'),
                onChanged: (bool? value) {
                  setState(() {
                    if (value != null && value) {
                      // If PriceOye is selected, unselect the other stores
                      selectedStores = ['PriceOye'];
                    } else {
                      selectedStores.remove('PriceOye');
                    }
                  });
                },
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: CheckboxListTile(
                title: const Text('HomeShopping'),
                activeColor: AppColors.purpleLight,
                value: selectedStores.contains('HomeShopping'),
                onChanged: (bool? value) {
                  setState(() {
                    if (value != null && value) {
                      // If HomeShopping is selected, unselect the other stores
                      selectedStores = ['HomeShopping'];
                    } else {
                      selectedStores.remove('HomeShopping');
                    }
                  });
                },
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: CheckboxListTile(
                title: const Text('ShopHive'),
                activeColor: AppColors.purpleLight,
                value: selectedStores.contains('ShopHive'),
                onChanged: (bool? value) {
                  setState(() {
                    if (value != null && value) {
                      // If ShopHive is selected, unselect the other stores
                      selectedStores = ['ShopHive'];
                    } else {
                      selectedStores.remove('ShopHive');
                    }
                  });
                },
              ),
            ),

            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(AppColors.purpleLight),
                    ),
                  onPressed: () {
                    Map<String, dynamic> filters = {};
                    if(selectedStores.isNotEmpty || selectedPriceRange != null){
                      filters = {
                        'selectedPriceRange': selectedPriceRange,
                        'selectedStores': selectedStores,
                      };
                    }else{
                      filters = {};
                    }

                    widget.onApplyFilter(filters);
                    Navigator.pop(context);
                  },
                  child: const Text('Apply Filter'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
