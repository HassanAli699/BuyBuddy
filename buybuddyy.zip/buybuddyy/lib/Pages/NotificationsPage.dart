import 'package:flutter/material.dart';

import '../Widgets/Colors.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backGroundColor,
      appBar: AppBar(
        elevation: 0.0,
        automaticallyImplyLeading: false,
        backgroundColor: AppColors.backGroundColor,
      ),
      //Body of the search page goes here
      body: Center(
        child: Text(
          "This is Notification Page",
          style: TextStyle(
              fontSize: 24,
              color: AppColors.textGreyColor2
          ),
        ),
      ),
    );
  }
}
