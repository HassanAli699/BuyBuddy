import 'dart:developer';
import 'package:buybuddyy/Helpers/Product_Controller.dart';
import 'package:buybuddyy/Helpers/Product_Model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import '../Home/TabsBottomNav/Product_details.dart';
import '../Widgets/Colors.dart';

class ProductPriceComparisonPage extends StatefulWidget {
  final Product product;
  const ProductPriceComparisonPage({super.key, required this.product});

  @override
  State<ProductPriceComparisonPage> createState() => _ProductPriceComparisonPageState();
}

class _ProductPriceComparisonPageState extends State<ProductPriceComparisonPage> {
  final searchController = TextEditingController();
  List<int> compareProductIds = [];
  List<Product> comparedProducts = [];

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Scaffold(
        backgroundColor: Theme.of(context).colorScheme.tertiary,
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                child: Row(
                  children: [
                     Text(
                      "Compare",
                      style: TextStyle(
                          overflow: TextOverflow.ellipsis,
                          color: Theme.of(context).colorScheme.secondary,
                          fontWeight: FontWeight.bold,
                          fontSize: 18),
                    ),
                    const Spacer(),
                    GestureDetector(
                        onTap: () {
                          _showSearchPopup(context);
                        },
                        child: const Icon(
                          Icons.add_box,
                          color: AppColors.purpleLight,
                        ))
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 2.0),
                child: Text(
                  "* How we Compare (Base Product Price - Compared Product Price)",
                  style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.bold, fontSize: 8),
                ),
              ),
              comparedProducts.isEmpty
                  ? Container()
                  : Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: comparedProducts.length,
                        itemBuilder: (context, index) {
                          Product product = comparedProducts[index];
                          return Card(
                            color: Theme.of(context).colorScheme.secondary,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4.0),
                              child: ListTile(
                                onTap: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (context) => ProductDetailsPage(product: product),
                                    ),
                                  );
                                },
                                leading:
                                    ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(product.productImage)),
                                title: Text(product.productName, style: TextStyle(color: Theme.of(context).colorScheme.tertiary),),
                                subtitle: Text('Price : ${product.productPrice} \nDifference : ${product.priceDifference}', style: TextStyle(color: Theme.of(context).colorScheme.tertiary),),
                                trailing: GestureDetector(
                                    onTap: () {
                                      compareProductIds.remove(product.productid);
                                      _compareProducts();
                                    },
                                    child:  Icon(
                                      Icons.cancel,
                                      color: Theme.of(context).colorScheme.primary,
                                    )),
                                // Add other details as needed
                              ),
                            ),
                          );
                        },
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  void _compareProducts() async {
    try {
      List<Product> result = await ProductController.compareProducts(
        widget.product.productid,
        compareProductIds,
      );

      setState(() {
        comparedProducts = result;
      });
    } catch (error) {
      log('Error in _compareProducts: $error');
    }
  }

  void _showSearchPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          contentPadding: EdgeInsets.zero,
          content: SingleChildScrollView(
            child: Column(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    FutureBuilder(
                      future: Future.delayed(Duration.zero),
                      builder: (context, snapshot) => snapshot.connectionState == ConnectionState.done
                          ? TypeAheadFormField(
                              hideSuggestionsOnKeyboardHide: false,
                              suggestionsBoxDecoration: SuggestionsBoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Theme.of(context).colorScheme.tertiary,
                              ),
                              textFieldConfiguration: TextFieldConfiguration(
                                style:  TextStyle(
                                  color: Theme.of(context).colorScheme.secondary,
                                ),
                                decoration: InputDecoration(
                                  suffixIcon: const Icon(
                                    Icons.arrow_drop_down,
                                    color: Colors.purple,
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey.shade700),
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(color: Colors.purple),
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  hintText: "Product Name",
                                  hintStyle: TextStyle(color: Theme.of(context).colorScheme.secondary),
                                  fillColor: Theme.of(context).colorScheme.tertiary,
                                  filled: true,
                                ),
                                controller: searchController,
                              ),
                              suggestionsCallback: (pattern) {
                                return ProductController.getSuggestions(pattern, widget.product.productCategory);
                              },
                              itemBuilder: (context, suggestion) {
                                return ListTile(
                                  leading: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                                    child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(suggestion.productImage)),
                                  ),
                                  title: Text(
                                    suggestion.productName,
                                    style:  TextStyle(color: Theme.of(context).colorScheme.secondary),
                                  ),
                                  subtitle: Text(
                                    "Rs.${suggestion.productPrice.toStringAsFixed(0)}",
                                    style:  TextStyle(color: Theme.of(context).colorScheme.secondary),
                                  ),
                                );
                              },
                              onSuggestionSelected: (suggestion) {
                                Navigator.pop(context);
                                compareProductIds.add(suggestion.productid);
                                _compareProducts();
                              },
                              getImmediateSuggestions: false,
                              hideOnEmpty: false,
                              hideOnError: true,
                            )
                          : Container(),
                    )
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
