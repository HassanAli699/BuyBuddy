import 'package:flutter/material.dart';

import '../Widgets/Colors.dart';

class PrivacyAndSecurity extends StatefulWidget {
  const PrivacyAndSecurity({super.key});

  @override
  State<PrivacyAndSecurity> createState() => _PrivacyAndSecurityState();
}

class _PrivacyAndSecurityState extends State<PrivacyAndSecurity> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backGroundColor,
      appBar: AppBar(
        elevation: 0.0,
        automaticallyImplyLeading: false,
        backgroundColor: AppColors.backGroundColor,
      ),
      //Body of the search page goes here
      body: Center(
        child: Text(
          "This is Privacy and Security Page",
          style: TextStyle(
              fontSize: 22,
              color: AppColors.textGreyColor2
          ),
        ),
      ),
    );
  }
}
