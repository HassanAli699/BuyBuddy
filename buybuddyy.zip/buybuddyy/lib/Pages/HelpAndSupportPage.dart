import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Widgets/Colors.dart';

class HelpAndSupport extends StatefulWidget {
  const HelpAndSupport({super.key});

  @override
  State<HelpAndSupport> createState() => _HelpAndSupportState();
}

class _HelpAndSupportState extends State<HelpAndSupport> {


  _launchEmail() async {
    final Uri _emailLaunchUri = Uri(
      scheme: 'mailto',
      path: 'ha468347@gmail.com',
      queryParameters: {'subject': 'Help&Support'},
    );
    final String emailLaunchUri = _emailLaunchUri.toString();
    try {
      await launch(emailLaunchUri);
    } catch (e) {
      print("Error launching email: $e");
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          "Help & Support",
          style: TextStyle(color: Theme.of(context).colorScheme.secondary),
        ),
        centerTitle: true,
        leading: Navigator.canPop(context)
            ? IconButton(
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).colorScheme.secondary,
          ),
        )
            : const Text(""),
        backgroundColor: Theme.of(context).colorScheme.background,
      ),
      // Body of the search page goes here
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const Text("Mail Your Queries at"),
            const SizedBox(height: 18),
            GestureDetector(
              onTap: _launchEmail,
              child: Text(
                " ha468347@gmail.com",
                style: TextStyle(
                  fontSize: 18,
                  color: Theme.of(context).colorScheme.primary,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
