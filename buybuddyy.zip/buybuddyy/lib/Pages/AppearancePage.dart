import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:provider/provider.dart';

import '../Widgets/Colors.dart';
import '../Widgets/ThemeProvider.dart';

class AppearancePage extends StatefulWidget {
  const AppearancePage({super.key});

  @override
  State<AppearancePage> createState() => _AppearancePageState();
}

class _AppearancePageState extends State<AppearancePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        elevation: 0.0,
        centerTitle: true,
        title:  Text("Appearance", style: TextStyle(color: Theme.of(context).colorScheme.secondary),),
        backgroundColor: Theme.of(context).colorScheme.background,
        leading: Navigator.canPop(context)
            ? IconButton(
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).colorScheme.secondary,
          ),
        )
            : const Text(""),
      ),
      //Body of the search page goes here
      body: Column(

        children: [

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: FractionallySizedBox(
              alignment: Alignment.topLeft,
              widthFactor: 0.9,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: Column(
                  children: [
                    Row(
                      children: [

                        const SizedBox(
                          width: 11,
                        ),
                        Text(
                          "Use System Settings",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            color: Theme.of(context).colorScheme.secondary,
                          ),
                        ),
                        const Spacer(),
                        FlutterSwitch(
                          width: 80.0,
                          height: 35.0,
                          toggleSize: 20.0,
                          value: Provider.of<ThemeProvider>(context, listen: false).useSystemSettings,
                          borderRadius: 30.0,
                          activeToggleColor: const Color(0xFF6E40C9),
                          inactiveToggleColor: AppColors.purpleLight,
                          activeSwitchBorder: Border.all(
                            color: AppColors.purpleLight,
                            width: 3.0,
                          ),
                          inactiveSwitchBorder: Border.all(
                            color: Colors.grey.shade200,
                            width: 3.0,
                          ),
                          activeColor: AppColors.purpleLight,
                          inactiveColor: Colors.white,
                          activeIcon: const Icon(
                            Icons.check,
                            color: Colors.white,
                          ),
                          inactiveIcon: const Icon(
                            Icons.cancel,
                            color: Colors.white,
                          ),
                          onToggle: (val) {
                            setState(() {
                              Provider.of<ThemeProvider>(context, listen: false).toggleSystemSettings();

                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 21,
                    ),

                    Visibility(
                      visible: !Provider.of<ThemeProvider>(context, listen: false).useSystemSettings,
                      child: Row(
                        children: [
                          const SizedBox(
                            width: 11,
                          ),
                          Text(
                            "Use App Settings",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          const Spacer(),
                          FlutterSwitch(
                            width: 80.0,
                            height: 35.0,
                            toggleSize: 20.0,
                            value: Provider.of<ThemeProvider>(context, listen: false).isDark(),
                            borderRadius: 30.0,
                            activeToggleColor: const Color(0xFF6E40C9),
                            inactiveToggleColor: AppColors.purpleLight,
                            activeSwitchBorder: Border.all(
                              color: AppColors.purpleLight,
                              width: 3.0,
                            ),
                            inactiveSwitchBorder: Border.all(
                              color: Colors.grey.shade200,
                              width: 3.0,
                            ),
                            activeColor: AppColors.purpleLight,
                            inactiveColor: Colors.white,
                            activeIcon: const Icon(
                              Icons.dark_mode_outlined,
                              color: Colors.white,
                            ),
                            inactiveIcon: const Icon(
                              Icons.light_mode,
                              color: Colors.white,
                            ),
                            onToggle: (val) {
                              setState(() {
                                Provider.of<ThemeProvider>(context, listen: false).toggleTheme();
                              });
                            },
                          ),
                        ],
                      ),
                    ),

                        ],
                      ),
                    ),
            ),
          )
                ],
              ),);


  }
}
