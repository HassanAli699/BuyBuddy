import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:flutter/material.dart';

class DynamicSearchBar extends StatefulWidget {
  final ValueChanged<String> onChanged;
  final ValueChanged<String> onSubmitted;
  final String? hint;

  DynamicSearchBar({
    required this.onChanged,
    required this.onSubmitted,
    this.hint
  });

  @override
  _DynamicSearchBarState createState() => _DynamicSearchBarState();
}

class _DynamicSearchBarState extends State<DynamicSearchBar> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.0),
          color: Theme.of(context).colorScheme.tertiary,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: TextField(
          cursorColor: Theme.of(context).colorScheme.primary,
          decoration: InputDecoration(
            hintText: widget.hint,
            border: InputBorder.none,
            icon: Icon(Icons.search, color: Theme.of(context).colorScheme.primary,),
          ),
          onChanged: widget.onChanged,
          onSubmitted: widget.onSubmitted,
        ),
      ),
    );
  }
}