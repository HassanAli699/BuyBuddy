import 'package:flutter/material.dart';

class AppColors {
  static const purpleLight = Color(0xFFA26FFD);
  static const textGreyColor = Color(0xFF333333);
  static const backGroundColor = Color(0xFF121212);
  static const textGreyColor2 = Color(0xFFBDBDBD);
  static const greyIconColor = Color(0xFF828282);
  static const bottomNavBackColor = Color(0xFFE5E5E5);
  static const lightBackColor = Color(0xFFF2F2F2);
}