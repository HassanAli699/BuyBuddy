import 'package:flutter/material.dart';

class CustomSnackBar extends SnackBar {
  CustomSnackBar({
    Key? key,
    required String text,
    required Color color,
    double? fontSize,
    Duration duration = const Duration(seconds: 4),
  }) : super(
    key: key,
    backgroundColor: color,
    shape: OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: Colors.transparent),
    ),
    margin: const EdgeInsets.all(25),
    behavior: SnackBarBehavior.floating,
    dismissDirection: DismissDirection.startToEnd,
    duration: duration,
    content: Row(
      children: [
        Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: fontSize != null ? fontSize : 16
          ),
        ),

        Spacer(),

        Icon(Icons.swipe_right, color: Colors.white,),
      ],
    ),
  );
}
