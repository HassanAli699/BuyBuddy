
import 'package:buybuddyy/Widgets/Theme.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
// Import the dart:ui library

class ThemeProvider with ChangeNotifier {
  ThemeData _themeData = lightMode;
  final String _themeKey = 'theme_key';
  bool _useSystemSettings = false;
  final String _useSystemSettingsKey = 'use_system_settings_key';

  ThemeData get themeData => _themeData;
  bool get useSystemSettings => _useSystemSettings;

  // Add a variable to store the context
  BuildContext? _context;

  // Add a method to set the context
  void setContext(BuildContext context) {
    _context = context;
  }

  ThemeProvider() {
    _loadTheme();
    _loadSystemSettings();
  }

  void _saveTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString(_themeKey, _themeData == lightMode ? 'light' : 'dark');
  }

  void _loadTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedTheme = prefs.getString(_themeKey);
    if (savedTheme == 'dark') {
      themeData = darkMode;
    }
  }

  void _saveSystemSettings() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool(_useSystemSettingsKey, _useSystemSettings);
  }

  void _loadSystemSettings() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? savedUseSystemSettings = prefs.getBool(_useSystemSettingsKey);
    if (savedUseSystemSettings != null) {
      _useSystemSettings = savedUseSystemSettings;
    }
  }

  set themeData(ThemeData themeData) {
    _themeData = themeData;
    _saveTheme();
    notifyListeners();
  }

  set useSystemSettings(bool value) {
    _useSystemSettings = value;
    _saveSystemSettings();
    notifyListeners();
  }

  void toggleSystemSettings() {
    _useSystemSettings = !_useSystemSettings;
    _saveSystemSettings();
    notifyListeners();
  }

  bool isDark() {
    return _themeData == darkMode;
  }

  void toggleTheme() {
    if (_themeData == lightMode) {
      themeData = darkMode;
    } else {
      themeData = lightMode;
    }
  }


  ThemeData getTheme() {
    // Use platform brightness if system settings are enabled
    return _useSystemSettings
        ? MediaQuery.platformBrightnessOf(_context!) == Brightness.light
        ? lightMode
        : darkMode
        : _themeData;
  }
}

