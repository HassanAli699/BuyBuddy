
import 'package:flutter/material.dart';

import 'Colors.dart';

class CustomTabBar extends StatelessWidget {
  final List<Widget> tabs;
  final List<String> tabNames;
  final Color indicatorColor;
  final double indicatorWeight;

  CustomTabBar({
    required this.tabs,
    required this.tabNames,
    this.indicatorColor = AppColors.purpleLight,
    this.indicatorWeight = 3.5,
  });

  String backColor = "#121212".replaceAll("#", "0xff");

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: null,
        body: Container(
          color: AppColors.backGroundColor,
          child: Column(
            children: [
              TabBar(
                indicatorColor: indicatorColor,
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorWeight: indicatorWeight,
                tabs: List.generate(
                  tabs.length,
                      (index) => Tab(
                    text: tabNames[index],
                  ),
                ),
              ),
              Expanded(
                child: TabBarView(children: tabs),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
