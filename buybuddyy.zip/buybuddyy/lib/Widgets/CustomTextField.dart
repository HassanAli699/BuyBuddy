import 'package:flutter/material.dart';

class CustomTextFormField extends StatelessWidget {
  final TextEditingController controller;
  final IconData iconData;
  final String hint;
  final Color fillColor;
  final bool? editable;

  const CustomTextFormField({
    Key? key,
    required this.controller,
    required this.iconData,
    required this.hint,
    required this.fillColor, this.editable,

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        enabled: editable,
        controller: controller,
        style: const TextStyle(
          color: Colors.white,
        ),
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon: Icon(
            iconData,
            color: const Color(0xFFBDBDBD),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: fillColor,
          filled: true,
        ),
      ),
    );
  }
}



