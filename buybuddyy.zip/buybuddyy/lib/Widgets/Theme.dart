import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:flutter/material.dart';


ThemeData lightMode = ThemeData(
  brightness: Brightness.light,
  colorScheme: const ColorScheme.light(
    primary: AppColors.purpleLight,
    background: AppColors.lightBackColor,
    secondary: AppColors.backGroundColor,
    tertiary: AppColors.textGreyColor2
  )
);

ThemeData darkMode = ThemeData(
  brightness: Brightness.dark,
  colorScheme: const ColorScheme.dark(
    primary: AppColors.purpleLight,
    background: AppColors.backGroundColor,
    secondary: AppColors.textGreyColor2,
    tertiary: AppColors.textGreyColor,

  ),
);
