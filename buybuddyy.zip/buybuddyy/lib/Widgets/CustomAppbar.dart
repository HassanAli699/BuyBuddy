
import 'package:flutter/material.dart';

import 'Colors.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String name;
  final String? imageUrl;
  final Color backgroundColor;
  final List<IconButton> actions;
  final Function()? onTap;

  CustomAppBar({
    required this.name,
    this.imageUrl,
    this.backgroundColor = AppColors.backGroundColor,
    this.actions = const [],
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0.0,
      backgroundColor: Theme.of(context).colorScheme.background,
      leading: Padding(
        padding: const EdgeInsets.all(4.0),
        child: GestureDetector(
          onTap: onTap,
          child: (imageUrl != null && imageUrl!.isNotEmpty)
              ? ClipOval(
                child: FadeInImage.assetNetwork(
            placeholder: 'lib/Assets/placeholder.png',
            image: imageUrl!,
            fit: BoxFit.cover,
          ),
              ):
          ClipOval(
            child: Image.asset(
              'lib/Assets/placeholder.png',
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
           Text(
            'Good morning!',
            style: TextStyle(
              fontSize: 14.0,
              color: Theme.of(context).colorScheme.secondary,
              fontWeight: FontWeight.w400,
            ),
          ),
          Text(
            name,
            style:  TextStyle(
              fontSize: 16.0,
              color: Theme.of(context).colorScheme.secondary,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
      actions: actions,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
