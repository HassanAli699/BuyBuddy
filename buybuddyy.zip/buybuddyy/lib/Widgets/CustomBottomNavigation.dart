
import 'package:flutter/material.dart';

import 'Colors.dart';

class CustomBottomNavBar extends StatelessWidget {
  final int pageIndex;
  final Function(int) onTap;
  final List<BottomNavigationBarItem> items;

  const CustomBottomNavBar({
    Key? key,
    required this.pageIndex,
    required this.onTap,
    required this.items,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15.0),
      child: Align(
        alignment: const Alignment(0.0, 1.0),
        child: BottomNavigationBar(
          selectedItemColor: AppColors.purpleLight,
          unselectedItemColor: Colors.grey,
          showSelectedLabels: true,
          showUnselectedLabels: false,
          backgroundColor: Theme.of(context).colorScheme.background,
          currentIndex: pageIndex,
          onTap: onTap,
          items: items,
        ),
      ),
    );
  }
}
