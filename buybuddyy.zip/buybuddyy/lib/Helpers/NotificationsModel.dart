class NotificationModel {
  final String title;
  final String description;
  final DateTime date;
  final String userId;
  final DateTime dateTime;
  final int productId;
  final String notificationId;

  NotificationModel({
    required this.title,
    required this.description,
    required this.date,
    required this.userId,
    required this.dateTime,
    required this.productId,
    required this.notificationId,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      date: DateTime.parse(json['date'] ?? ''),
      userId: json['user_id'] ?? '',
      dateTime: DateTime.parse(json['dateTime'] ?? ''),
      productId: json['product_id'] ?? 0,
      notificationId: json['notification_id'] ?? 0,

    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'date': date.toIso8601String(),
      'user_id': userId,
      'dateTime': dateTime.toIso8601String(),
      'product_id': productId,
      'notification_id':notificationId
    };
  }
}
