
class ApiConstants {
  static const String baseUrl = 'http://192.168.162.197:5000'; // Home Network : http://192.168.100.7:5000
  static const String recommend = '$baseUrl/recommend';
  static const String topRatedProducts = '$baseUrl/top_rated_products';
  static const String searchProducts = '$baseUrl/search_products';
  static const String getComparedProducts = '$baseUrl/get_compared_products';
  static const String getAllProducts = '$baseUrl/get_all_products';
  static const String getCollaborativeRecommendations = '$baseUrl/collaborative_recommendations';
  static const String getHybridRecommendations = '$baseUrl/hybrid_recommendations';
  static const String getComparePrices = '$baseUrl/compare_prices';
  static const String submitRatings = '$baseUrl/submit_rating';
}

  /*

  Params :
  page : 1  - For the page number
  per_page: 10 - How many products i want per page
  min_price : 10 - the minimum Price of the products i want to get
  max_price : 1000 - the maximum Price of the products i want to get
  store: priceOye - the store from which i want to get my products
  category : Mobile-Phones - the category of the products
  product_name : iphone 14 - the name of the products

  The Recommend API accepts the product name as the parameter.
  The Top Rated API accepts the category or store but none is must it will return page 1 and 10 items if they are not specified
  The Search API accepts all the parameters But none is required it return the products pre sorted
  The Compared API accepts the user_search or product name as parameters and it return the product from different store (sorted)
  The Get All Products Api returns all the products present in the dataset by paginating them
  The getCollaborativeRecommendations Api return the recommendation using collaborative filtering it takes product name parameter
  The getHybridRecommendations API returns the content and collaborative recommendations combined it takes the name as parameter
  The getComparePrices API returns the compared price it takes a product id to compare the price and a list of product ids from
  which the prices are to be compared.

  */



