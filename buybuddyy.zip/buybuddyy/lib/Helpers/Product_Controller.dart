import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'API_Constants.dart';
import 'Product_Model.dart';

// Product Controller Class that deals with fetching data from the Flask APIs
class ProductController {
  static Future<List<Product>> fetchTopRatedProducts({int page = 1, int perPage = 10, String? category, String? store}) async {
    final Uri uri;
    if (category != null) {
      uri = Uri.parse('${ApiConstants.topRatedProducts}?page=$page&category=$category&store=$store&per_page=$perPage');
    } else {
      uri = Uri.parse('${ApiConstants.topRatedProducts}?page=$page&per_page=$perPage');
    }

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['Data'];
      List<Product> products = data.map((json) => Product.fromJson(json)).toList();
      return products;
    } else {
      log('Failed to load products: ${response.statusCode} Error : ${response.body.toString()}');
      return [];
    }
  }

  static Future<List<Product>> fetchRecommendedProducts({int page = 1, int perPage = 10, required String productName}) async {
    final Uri uri = Uri.parse('${ApiConstants.recommend}?page=$page&per_page=$perPage&product_name=$productName');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['Data'];
      List<Product> products = data.map((json) => Product.fromJson(json)).toList();
      return products;
    } else {
      log('Failed to load Recommended products: ${response.statusCode} Error : ${response.body.toString()}');
      return [];
    }
  }

  static Future<List<Product>> searchProducts(
      {String? productName,
      required int page,
      required int perPage,
      List<String>? tags,
      required bool isCompare,
      int? minPrice,
      int? maxPrice,
      String? store}) async {
    final Uri uri;

    uri = Uri.parse('${ApiConstants.searchProducts}?&page=$page&per_page=$perPage&min_price=${minPrice}&isCompare=${false}&max_price=${maxPrice}&category=${tags?.join(',')}&store=$store&product_name=$productName');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['Data'];
      List<Product> products = data.map((json) => Product.fromJson(json)).toList();
      return products;
    } else {
      throw Exception('Failed to load search results: ${response.statusCode}');
    }
  }

  static Future<List<Product>> fetchOtherStoresProducts(
      {required String userSearch, required int page, required int perPage}) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConstants.getComparedProducts}?user_search=$userSearch&page=$page&per_page=$perPage'),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body)['Data'];
        List<Product> products = data.map((json) => Product.fromJson(json)).toList();
        return products;
      } else {
        throw Exception('Failed to fetch recommended products');
      }
    } catch (error) {
      throw Exception('Error: $error');
    }
  }

  static Future<List<Product>> compareProducts(int mainProductId, List<int> comparedProductIds) async {
    const String apiUrl = ApiConstants.getComparePrices;

    String comparedProductIdsParam = '';
    for (int id in comparedProductIds) {
      comparedProductIdsParam += 'compare_product_ids[]=$id&';
    }

    Uri uri = Uri.parse('$apiUrl?product_id=$mainProductId&$comparedProductIdsParam');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['Data'];
      List<Product> products = data.map((item) => Product.fromJson(item)).toList();
      return products;
    } else {
      throw Exception('Failed to load compared products: ${response.statusCode}');
    }
  }

  static Future<List<Product>> getSuggestions(String pattern, String category) async {
    List<String> newCategory = category.split(", ");

    final Uri uri;

    uri = Uri.parse('${ApiConstants.searchProducts}?&page=${1}&per_page=${100}&isCompare=${false}&category=${newCategory[0]}&product_name=$pattern');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['Data'];
      List<Product> products = data.map((json) => Product.fromJson(json)).toList();


      // Filter the products based on your criteria
      List<Product> filteredProducts = products.where((product) {
        // Add your filtering logic here, for example:
        return product.productName.toLowerCase().contains(pattern.toLowerCase());
      }).toList();

      return filteredProducts;
    }else{
      log('Failed to load Suggestion products: ${response.statusCode} Error : ${response.body.toString()}');
      return [];
    }

  }

  static Future<List<Product>> fetchHybridRecommendedProducts(
      {int page = 1, int perPage = 10, required String productName}) async {
    final Uri uri = Uri.parse('${ApiConstants.getHybridRecommendations}?page=$page&per_page=$perPage&product_name=$productName');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body)['Data'];
      List<Product> products = data.map((json) => Product.fromJson(json)).toList();
      return products;
    } else {
      log('Failed to load Recommended products: ${response.statusCode} Error : ${response.body.toString()}');
      return [];
    }
  }

}
