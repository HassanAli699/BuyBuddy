import 'dart:convert';

import 'package:buybuddyy/Helpers/Product_Model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class FavoritesDatabase {
  static Database? _database;
  static const String tableName = 'favorites';

  static Future<Database> _initializeDatabase() async {
    final String path = join(await getDatabasesPath(), 'favorites_database.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) {
        return db.execute(
            '''
          CREATE TABLE $tableName(
            product_id INTEGER PRIMARY KEY,
            product_name TEXT,
            product_link TEXT,
            product_image TEXT,
            product_price REAL,
            product_category TEXT,
            product_ratings REAL,
            product_rating_count REAL,
            product_description TEXT,
            product_fetch_date TEXT,
            product_store TEXT,
            rating_weighted REAL,
            price_difference REAL
          )
        '''
        );
      },
    );
  }

  static Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initializeDatabase();
    return _database!;
  }

  static Future<void> insertFavorite(Product product) async {
    final Database db = await database;
    await db.insert(
      tableName,
      {
        'product_id': product.productid,
        'product_name': product.productName,
        'product_link': product.productLink,
        'product_image': product.productImage,
        'product_price': product.productPrice,
        'product_category': product.productCategory,
        'product_ratings': product.productRatings,
        'product_rating_count': product.productRatingCount,
        'product_description': product.productDescription,
        'product_fetch_date': product.productFetchDate,
        'product_store': product.productStore,
        'rating_weighted': product.ratingWeighted,
        'price_difference': product.priceDifference,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<bool> isFavorite(int productId) async {
    final Database db = await database;
    final List<Map<String, dynamic>> result = await db.query(
      tableName,
      columns: ['product_id'],
      where: 'product_id = ?',
      whereArgs: [productId],
    );

    return result.isNotEmpty; // Returns true if the product is a favorite, false otherwise
  }


  static Future<List<Product>> getFavorites() async {
    final Database db = await database;
    final List<Map<String, dynamic>> maps = await db.query(tableName);

    return List.generate(maps.length, (i) {
      final Map<String, dynamic> map = maps[i];
      final Product product = Product(
        productid: map['product_id'],
        productName: map['product_name'],
        productLink: map['product_link'],
        productImage: map['product_image'],
        productPrice: map['product_price'],
        productCategory: map['product_category'],
        productRatings: map['product_ratings'],
        productRatingCount: map['product_rating_count'],
        productDescription: map['product_description'],
        productFetchDate: map['product_fetch_date'],
        productStore: map['product_store'],
        ratingWeighted: map['rating_weighted'],
        priceDifference: map['price_difference'],
      );
      return product;
    });
  }

  static Future<void> deleteFavorite(int productId) async {
    final Database db = await database;
    await db.delete(
      tableName,
      where: 'product_id = ?',
      whereArgs: [productId],
    );
  }
}
