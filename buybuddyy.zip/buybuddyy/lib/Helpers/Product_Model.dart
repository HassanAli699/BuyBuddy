import 'dart:convert';

class Product {
  final int productid;
  final String productName;
  final String productLink;
  final String productImage;
  final double productPrice;
  final String productCategory;
  final double productRatings;
  final double productRatingCount;
  final String productDescription;
  final String productFetchDate;
  final String productStore;
  final double ratingWeighted;
  final double? priceDifference;

  Product({
    required this.productid,
    required this.productName,
    required this.productLink,
    required this.productImage,
    required this.productPrice,
    required this.productCategory,
    required this.productRatings,
    required this.productRatingCount,
    required this.productDescription,
    required this.productFetchDate,
    required this.productStore,
    required this.ratingWeighted,
    this.priceDifference
  });


  factory Product.fromJson(Map<String, dynamic> json) {

    return Product(
      productid: json['product_id'],
      productName: json['product_name'],
      productLink: json['product_link'],
      productImage: json['product_image'],
      productPrice: json['product_price'],
      productCategory: json['product_category'],
      productRatings: json['product_ratings'],
      productRatingCount: json['product_rating_count'],
      productDescription: json['product_description'],
      productFetchDate: json['product_fetch_date'],
      productStore: json['product_store'],
      ratingWeighted:  json['product_weighted_rating'],
      priceDifference: json['price_difference']?.toDouble(),
    );
  }

  Map<String, dynamic> toMap() {

    String formattedDescription = '';

    return {
      'product_id': productid,
      'product_name': productName,
      'product_link': productLink,
      'product_image': productImage,
      'product_price': productPrice,
      'product_category': productCategory,
      'product_ratings': productRatings,
      'product_rating_count': productRatingCount,
      'product_description': formattedDescription,
      'product_fetch_date': productFetchDate,
      'product_store': productStore,
      'rating_weighted':ratingWeighted,
      'price_difference':priceDifference ?? 0.0
    };
  }

  String toJson() {
    return json.encode(toMap());
  }
}

String formatDescriptionString(String jsonString) {
  // Remove curly brackets
  String withoutBrackets = jsonString.replaceAll(RegExp(r'[{}\"]'), '');

  // Replace colons with equal signs
  String withoutColons = withoutBrackets.replaceAll(':', '=');

  // Replace commas with line breaks
  String formattedString = withoutColons.replaceAll(',', '\n');

  return formattedString;
}
