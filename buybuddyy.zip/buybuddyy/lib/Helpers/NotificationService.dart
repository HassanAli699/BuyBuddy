import 'package:cloud_firestore/cloud_firestore.dart';

import 'NotificationsModel.dart';

class FirebaseNotificationService {
  final CollectionReference _notificationCollection =
  FirebaseFirestore.instance.collection('notifications');

  Future<void> addNotification(NotificationModel notification) async {
    final dateTime = notification.dateTime.toIso8601String(); // Format dateTime as a String
    await _notificationCollection.doc(dateTime).set(notification.toJson());
  }

  Future<void> deleteNotification(String userId, DateTime dateTime) async {
    final dateTimeString = dateTime.toIso8601String();
    await _notificationCollection.doc(dateTimeString).delete();
  }

  Future<List<NotificationModel>> getNotifications(String userId) async {
    final QuerySnapshot<Map<String, dynamic>> snapshot = await _notificationCollection
        .where('user_id', isEqualTo: userId)
        .orderBy('dateTime', descending: true)
        .get() as QuerySnapshot<Map<String, dynamic>>;

    return snapshot.docs
        .map((doc) => NotificationModel.fromJson(doc.data()))
        .toList();
  }

}
