import 'dart:convert';
import 'dart:developer';
import 'package:buybuddyy/Helpers/API_Constants.dart';
import 'package:buybuddyy/Helpers/userData.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class Helpers{
  final FirebaseFirestore _fireStore = FirebaseFirestore.instance;

  Future<void> saveUserToDatabase(GoogleSignInAccount googleUser, GoogleSignInAuthentication googleAuth) async {
    // Get user information
    String email = googleUser.email;
    String profilePicUrl = googleUser.photoUrl ?? '';
    String name = googleUser.displayName ?? '';

    // Create a document reference using the user's email as the document ID
    DocumentReference userDocument = _fireStore.collection('Users').doc(email);

    // Set the user information in the document
    await userDocument.set({
      'email': email,
      'profilePicUrl': profilePicUrl,
      'userName': name,
      'phoneNumber': ''
    });

  }
  Future<bool> checkUserExists(GoogleSignInAccount googleUser) async {
    String email = googleUser.email;
    DocumentSnapshot userSnapshot = await _fireStore.collection('Users').doc(email).get();
    return userSnapshot.exists;
  }
  Future<Map<String, dynamic>> getUserDataFromFireStore(String email) async {
    DocumentSnapshot userSnapshot = await _fireStore.collection('Users').doc(email).get();
    if (userSnapshot.exists) {
      return userSnapshot.data() as Map<String, dynamic>;
    }
    return {};
  }
  Future<void> saveUserToSharedPreferences(Map<String, dynamic> userDataFromDatabase) async {

    final userData = UserData(await SharedPreferences.getInstance());

    // Save user information to shared preferences
    userData.setEmail(userDataFromDatabase['email']);
    userData.setProfilePicUrl(userDataFromDatabase['profilePicUrl']);
    userData.setUsername(userDataFromDatabase['userName']);
    userData.setPhoneNumber(userDataFromDatabase['phoneNumber']);

    log('Email: ${userData.email}');
    log('Profile Picture URL: ${userData.profilePicUrl}');
    log('Username: ${userData.username}');
    log('Phone Number: ${userData.phoneNumber}');
  }

  Future<void> submitRating({
    required double rating,
    required String review,
    required String userId,
    required String productId,
  }) async {
    const url = ApiConstants.submitRatings;
    final headers = {'Content-Type': 'application/json'};
    final body = jsonEncode({
      'user_id': userId,
      'product_id': productId,
      'user_rating': rating,
      'timestamp': DateTime.now().toIso8601String(),
      'review': review,
    });

    try {
      final response = await http.post(Uri.parse(url), headers: headers, body: body);

      if (response.statusCode == 201) {
        log('Rating submitted successfully');
      } else {
        log('Failed to submit rating. Status code: ${response.statusCode}');
      }
    } catch (error) {
      log('Error submitting rating: $error');
    }
  }

  // Helper function to extract max price from the selected price range
  int extractMaxPrice(String? priceRange) {
    if (priceRange != null && priceRange.isNotEmpty) {
      // Extract the numeric part of the price range (e.g., "Rs.50,000 - Rs.10,0000" => 100000)
      final maxPriceString = priceRange.split(' - ').last.replaceAll('Rs.', '').replaceAll(',', '');
      return int.parse(maxPriceString);
    }
    return 1000000000; // Default value if no price range is selected
  }

  // Helper function to extract min price from the selected price range
  int extractMinPrice(String? priceRange ) {
    if (priceRange != null && priceRange.isNotEmpty) {
      // Extract the numeric part of the price range (e.g., "Rs.50,000 - Rs.10,0000" => 50000)
      final minPriceString = priceRange.split(' - ').first.replaceAll('Rs.', '').replaceAll(',', '');
      return int.parse(minPriceString);
    }
    return 0; // Default value if no price range is selected
  }

}