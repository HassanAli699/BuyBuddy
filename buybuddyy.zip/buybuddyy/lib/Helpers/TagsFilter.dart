import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:flutter/material.dart';

class TagsFilter extends StatelessWidget {
  final List<String> tags;
  final List<String> selectedTags;
  final ValueChanged<String> onTagSelected;

  TagsFilter({
    required this.tags,
    required this.selectedTags,
    required this.onTagSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: tags.map((tag) {
          final isSelected = selectedTags.contains(tag);

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: FilterChip(
              label: Text(
                tag,
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.black,
                ),
              ),
              backgroundColor: isSelected ? AppColors.purpleLight : AppColors.textGreyColor2,
              onSelected: (value) {
                onTagSelected(tag);
              },
              selected: isSelected,
              selectedColor: AppColors.purpleLight,
            ),
          );
        }).toList(),
      ),
    );
  }
}
