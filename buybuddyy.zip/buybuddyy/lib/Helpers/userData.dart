import 'package:shared_preferences/shared_preferences.dart';

class UserData {
  static const String _keyEmail = 'email';
  static const String _keyProfilePicUrl = 'profilePicUrl';
  static const String _keyUsername = 'userName';
  static const String _keyPhoneNumber = 'phoneNumber';

  final SharedPreferences _prefs;

  UserData(this._prefs);

  // Getters
  String get email => _prefs.getString(_keyEmail) ?? '';
  String get profilePicUrl => _prefs.getString(_keyProfilePicUrl) ?? '';
  String get username => _prefs.getString(_keyUsername) ?? '';
  String get phoneNumber => _prefs.getString(_keyPhoneNumber) ?? '';

  // Setters
  Future<void> setEmail(String email) async {
    await _prefs.setString(_keyEmail, email);
  }

  Future<void> setProfilePicUrl(String profilePicUrl) async {
    await _prefs.setString(_keyProfilePicUrl, profilePicUrl);
  }

  Future<void> setUsername(String username) async {
    await _prefs.setString(_keyUsername, username);
  }

  Future<void> setPhoneNumber(String phoneNumber) async {
    await _prefs.setString(_keyPhoneNumber, phoneNumber);
  }

  // Clear user data
  Future<void> clearUserData() async {
    await _prefs.remove(_keyEmail);
    await _prefs.remove(_keyProfilePicUrl);
    await _prefs.remove(_keyUsername);
    await _prefs.remove(_keyPhoneNumber);
  }

  // Check if user data exists
  bool get hasUserData =>
      _prefs.containsKey(_keyEmail) &&
          _prefs.containsKey(_keyProfilePicUrl) &&
          _prefs.containsKey(_keyUsername) &&
          _prefs.containsKey(_keyPhoneNumber);
}
