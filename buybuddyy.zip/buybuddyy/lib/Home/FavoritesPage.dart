import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import '../Helpers/DatabaseHelper.dart';
import '../Helpers/Product_Model.dart';
import '../Widgets/Colors.dart';
import 'TabsBottomNav/Product_Card.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  List<Product> favorites = [];


  Future<void> _fetchFavorites() async {
    final List<Product> fetchedFavorites = await FavoritesDatabase.getFavorites();

    if(mounted){
      setState(() {
        favorites = fetchedFavorites;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fetchFavorites();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        elevation: 0.0,
        title:  Text("Your Favorites", style: TextStyle(color: Theme.of(context).colorScheme.secondary),),
        centerTitle: true,
        leading: Navigator.canPop(context) ? IconButton(
          onPressed: () {
            if(Navigator.canPop(context)){
              Navigator.pop(context);
            }
          },
          icon:  Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).colorScheme.secondary,
          ),
        ) : const Text(""),
        backgroundColor: Theme.of(context).colorScheme.background,
      ),
      body: favorites.isEmpty
          ? const Center(
              child: Text(
                "Your Favorites are Empty",
                style: TextStyle(
                  fontSize: 24,
                  color: AppColors.textGreyColor2,
                ),
              ),
            )
          : StaggeredGridView.countBuilder(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                Product product = favorites[index];
                return ProductCard(product: product, index: index);
              },
              staggeredTileBuilder: (index) {
                return const StaggeredTile.fit(1); // StaggeredTile for regular products
              },
            ),
    );
  }
}
