import 'package:buybuddyy/Home/FavoritesPage.dart';
import 'package:buybuddyy/Home/TabsBottomNav/HomePage.dart';
import 'package:flutter/material.dart';

import '../Widgets/CustomBottomNavigation.dart';
import 'TabsBottomNav/ProfilePage.dart';
import 'TabsBottomNav/CartPage.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {


  //Variables
  int _pageIndex = 0;

  final List<Widget> _tabsList = [
    const HomePage(), const FavoritesPage(), const ProfilePage(),
  ];

  final List<BottomNavigationBarItem> bottomNavBarItems = [
    const BottomNavigationBarItem(
      icon: Icon(Icons.home_filled),
      label: "Home",
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.favorite),
      label: "Favorites",
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: "Profile",
    ),
  ];


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Stack(
        children: [
          _tabsList.elementAt(_pageIndex),
          CustomBottomNavBar(
            pageIndex: _pageIndex,
            onTap: (int index) {
              setState(() {
                _pageIndex = index;
              });
            },
            items: bottomNavBarItems,
          ),

        ],
      ),

    );
  }
}
