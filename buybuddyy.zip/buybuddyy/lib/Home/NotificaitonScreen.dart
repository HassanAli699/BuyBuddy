import 'package:buybuddyy/Helpers/Product_Controller.dart';
import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';


import '../Helpers/NotificationService.dart';
import '../Helpers/NotificationsModel.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({Key? key}) : super(key: key);

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  List<NotificationModel> userNotifications = [];
  final user = FirebaseAuth.instance.currentUser!;
  FirebaseNotificationService firebaseService = FirebaseNotificationService();

  Future<void> getNotifications() async {
    List<NotificationModel> userNotification = await firebaseService.getNotifications(user.uid);

    setState(() {
      userNotifications = userNotification;
    });
  }

  @override
  void initState() {
    super.initState();
    getNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: Text(
          "Notifications",
          style: TextStyle(color: Theme.of(context).colorScheme.secondary),
        ),
        elevation: 0.0,
        centerTitle: true,
        leading: Navigator.canPop(context)
            ? IconButton(
                onPressed: () {
                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                },
                icon: Icon(
                  Icons.arrow_back_ios,
                  color: Theme.of(context).colorScheme.secondary,
                ),
              )
            : const Text(""),
        backgroundColor: Theme.of(context).colorScheme.background,
      ),
      body: ListView.builder(
          itemCount: userNotifications.length,
          itemBuilder: (context, index) {
            return InkWell(
              onTap: (){

              },

              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Card(
                  color: Theme.of(context).colorScheme.tertiary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Slidable(
                      endActionPane: ActionPane(
                        motion: const StretchMotion(),

                        children: [
                          SlidableAction(
                            icon: Icons.delete,
                              backgroundColor: AppColors.purpleLight,
                              borderRadius: BorderRadius.circular(20),
                              padding: EdgeInsets.zero,
                              onPressed: (context){
                                    firebaseService.deleteNotification(user.uid, userNotifications[index].dateTime);
                                    setState(() {
                                      getNotifications();
                                    });
                          })
                        ],
                      ),
                      child: ListTile(
                        title: Text(userNotifications[index].title, style: const TextStyle(fontWeight: FontWeight.bold),),
                        subtitle: Text(userNotifications[index].description),
                        // Add more fields as needed
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
    );
  }
}
