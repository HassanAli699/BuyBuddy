import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:flutter/material.dart';

class CartPage extends StatefulWidget {
  const CartPage({Key? key}) : super(key: key);

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backGroundColor,
      appBar: AppBar(
        elevation: 0.0,
        automaticallyImplyLeading: false,
        backgroundColor: AppColors.backGroundColor,
      ),
      //Body of the search page goes here
      body: Center(
        child: Text(
          "Your Cart is Empty",
          style: TextStyle(
            fontSize: 24,
            color: AppColors.textGreyColor2
          ),
        ),
      ),
    );
  }
}
