import 'package:buybuddyy/Helpers/WebView.dart';
import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:flutter/material.dart';

import '../../Helpers/Product_Model.dart';

class ProductStorePage extends StatefulWidget {
  final Product product;
  const ProductStorePage({super.key, required this.product});

  @override
  State<ProductStorePage> createState() => _ProductStorePageState();
}

class _ProductStorePageState extends State<ProductStorePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backGroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.backGroundColor,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back_ios,
            color: AppColors.textGreyColor2,
          ),
        ),
      ),
      body: WebViewPage(
        url: widget.product.productLink,
      ),
    );
  }
}
