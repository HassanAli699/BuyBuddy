import 'package:flutter/material.dart';

import '../../Helpers/Product_Model.dart';
import '../../Widgets/Colors.dart';
import 'Product_details.dart';

class RecommendedProductCard extends StatelessWidget {
  final Product product;

  const RecommendedProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => ProductDetailsPage(product: product),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8.0),
        width: 150.0,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 150.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
                image: DecorationImage(
                  image: NetworkImage(product.productImage),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 8.0),
            Text(
              product.productName,
              style:  TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold,  color: Theme.of(context).colorScheme.secondary),
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4.0),
            Text(
              'Rs. ${product.productPrice}',
              style:  TextStyle(fontSize: 12.0, color: Theme.of(context).colorScheme.secondary),
            ),
            const SizedBox(height: 4.0),
            Text(
              'Store: ${product.productStore}',
              style:  TextStyle(fontSize: 12.0, color: Theme.of(context).colorScheme.secondary),
            ),
          ],
        ),
      ),
    );
  }
}
