import 'package:buybuddyy/Helpers/Product_Model.dart';
import 'package:buybuddyy/Helpers/helpers.dart';
import 'package:buybuddyy/Home/TabsBottomNav/ProductStorePage.dart';
import 'package:buybuddyy/Pages/ProductPriceComparisonPage.dart';
import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'dart:developer' as dev;
import '../../Helpers/DatabaseHelper.dart';
import '../../Helpers/NotificationService.dart';
import '../../Helpers/NotificationsModel.dart';
import '../../Helpers/PlaceHolderImage.dart';
import '../../Helpers/Product_Controller.dart';
import '../../Widgets/CustomSnackBar.dart';
import 'Product_Card.dart';

class ProductDetailsPage extends StatefulWidget {
  final Product product;
  const ProductDetailsPage({super.key, required this.product});

  @override
  State<ProductDetailsPage> createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends State<ProductDetailsPage> {

  final ScrollController _scrollController = ScrollController();
  FirebaseNotificationService firebaseService = FirebaseNotificationService();
  final user = FirebaseAuth.instance.currentUser!;
  List<Product> otherStoreProducts = [];
  List<Product> recommendedProducts = [];
  int itemsPerPage = 10;
  int currentPage = 1;
  int recommendedPage = 1;
  bool isLoading = false;
  bool noMoreProducts = false;
  bool isFavorite = false;

  Future<void> _fetchProducts() async {
    setState(() {
      currentPage = 1;
      isLoading = true;
    });
    try {
      List<Product> fetchedProducts = await ProductController.fetchOtherStoresProducts(
          page: currentPage, perPage: itemsPerPage, userSearch: widget.product.productName);

      fetchedProducts = fetchedProducts.where((product) => product.productLink != widget.product.productLink).toList();
      setState(() {
        otherStoreProducts = fetchedProducts;
        isLoading = false;
      });
    } catch (error) {
      // Handle errors
      dev.log('Failed to fetch products: $error');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _fetchRecommendedProducts() async {
    setState(() {
      recommendedPage = 1;
      isLoading = true;
    });
    try {
      List<Product> fetchedProducts = await ProductController.fetchHybridRecommendedProducts(
          page: recommendedPage, perPage: itemsPerPage, productName: widget.product.productName);

      setState(() {
        recommendedProducts = fetchedProducts;
        isLoading = false;
      });
    } catch (error) {
      dev.log('Failed to fetch products: $error');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _fetchProducts();
    _fetchRecommendedProducts();
    _checkFavoriteStatus();

    _scrollController.addListener(() {
      if (_scrollController.position.pixels == _scrollController.position.maxScrollExtent) {
        _loadNextRecommendedPage();
      }
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Theme.of(context).colorScheme.background,
        title: Text(widget.product.productName, style: TextStyle(color: Theme.of(context).colorScheme.secondary),),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon:  Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).colorScheme.secondary,
          ),
        ),
        actions: [
          IconButton(
              onPressed: () {
                _toggleFavorite();
              },
              icon: isFavorite
                  ? const Icon(
                      Icons.favorite_outlined,
                      color: AppColors.purpleLight,
                    )
                  :  Icon(Icons.favorite_border_outlined, color: Theme.of(context).colorScheme.secondary,)),
          IconButton(
              onPressed: () {
                showModalBottomSheet(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  context: context,
                  builder: (BuildContext context) {
                    return ProductPriceComparisonPage(product: widget.product);
                  },
                );
              },
              icon:  Icon(Icons.compare, color: Theme.of(context).colorScheme.secondary,))
        ],
      ),
      body: CustomScrollView(
        controller: _scrollController,
        slivers:[
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 4.0),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    color: Theme.of(context).colorScheme.tertiary,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Material(
                          elevation: 10, // Adjust the elevation value
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: InteractiveViewer(
                            maxScale: 4.0,
                            minScale: 1.0,
                            child: Container(
                              height: 300,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image: NetworkImage(widget.product.productImage), // Replace with your image source
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Text(
                            widget.product.productName,
                            style:  TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary, fontSize: 18),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        if (widget.product.productPrice == 0.0)
                           Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              'Price: Coming Soon',
                              style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary),
                            ),
                          ),
                        if (widget.product.productPrice != 0.0)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              'Price: Rs ${NumberFormat('#,##0').format(widget.product.productPrice)}',
                              style:  TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary),
                            ),
                          ),
                        const SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Text(
                            "Store : ${widget.product.productStore}",
                            style:  TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary),
                          ),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Text(
                            "Category : ${widget.product.productCategory}",
                            style:  TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary),
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8.0),
                              child: RatingBar(
                                initialRating: widget.product.productRatings, // Use your product's rating value
                                direction: Axis.horizontal,
                                allowHalfRating: true,
                                itemCount: 5,
                                itemSize: 20.0,
                                itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
                                ratingWidget: RatingWidget(
                                  full: const Icon(Icons.star, color: AppColors.purpleLight),
                                  half: const Icon(Icons.star_half, color: AppColors.purpleLight),
                                  empty: const Icon(Icons.star_border, color: AppColors.purpleLight),
                                ),
                                onRatingUpdate: (rating) {
                                  // Handle rating updates if needed
                                },
                              ),
                            ),
                            Text(
                              "(${widget.product.productRatings.toStringAsFixed(1)})",
                              style:  TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary),
                            ),
                            const Spacer(),
                            IconButton(
                                onPressed: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (context) => ProductStorePage(product: widget.product),
                                    ),
                                  );
                                },
                                icon: const Icon(
                                  Icons.arrow_forward_ios,
                                  color: AppColors.purpleLight,
                                ))
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
                ),

                // Other stores card

                isLoading
                    ?  Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SpinKitThreeBounce(
                    size: 20,
                    color: Theme.of(context).colorScheme.secondary,
                  ),
                )
                    : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 0.0),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    color: Theme.of(context).colorScheme.tertiary,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                         Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              'Other Stores',
                              style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary, fontSize: 18),
                            ),
                          ),
                        ),
                        // ListView for other stores
                        otherStoreProducts.isEmpty
                            ?  Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  "No More Products",
                                  style: TextStyle(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.bold),
                                ),
                              )),
                        )
                            : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          scrollDirection: Axis.vertical,
                          itemCount: otherStoreProducts.length,
                          itemBuilder: (BuildContext context, int index) {
                            return ListTile(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => ProductDetailsPage(product: otherStoreProducts[index]),
                                  ),
                                );
                              },
                              leading: ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.network(
                                    otherStoreProducts[index].productImage,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const PlaceholderImageWidget();
                                    },
                                  )),
                              title: Text(
                                otherStoreProducts[index].productName,
                                style: TextStyle(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.w500),
                              ),
                              subtitle: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4.0),
                                child: Text(
                                  '${otherStoreProducts[index].productStore} - Rs ${NumberFormat('#,##0').format(otherStoreProducts[index].productPrice)}',
                                  style: const TextStyle(
                                      color: AppColors.purpleLight, fontWeight: FontWeight.w500, fontSize: 12),
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(
                  height: 20,
                ),

                const Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 20.0),
                  child: Divider(
                    color: AppColors.textGreyColor2,
                  ),
                ),

                 Padding(
                  padding:  const EdgeInsets.symmetric(horizontal: 8.0, vertical: 10),
                  child: Text("Other Users Also Liked", style: TextStyle(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.bold,fontSize: 18),),
                )


                // Recommended Products
              ],
            ),
          ),
          SliverStaggeredGrid.countBuilder(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            itemCount: recommendedProducts.length,
            itemBuilder: (context, index) {
                  Product product = recommendedProducts[index];
                  return ProductCard(product: product, index: index);
            },
            staggeredTileBuilder: (index) {
                return const StaggeredTile.fit(1); // StaggeredTile for regular products
            },
          ),
        ]
      ),
    );
  }

  Future<void> _checkFavoriteStatus() async {
    bool favoriteStatus = await FavoritesDatabase.isFavorite(widget.product.productid);
    setState(() {
      isFavorite = favoriteStatus;
    });
  }

  Future<void> _loadNextPage() async {
    setState(() {
      currentPage++;
    });
    try {
      List<Product> nextPageProducts = await ProductController.fetchOtherStoresProducts(
        page: currentPage,
        perPage: itemsPerPage,
        userSearch: widget.product.productName,
      );

      if (nextPageProducts.isNotEmpty) {
        setState(() {
          otherStoreProducts.addAll(nextPageProducts);
        });
      } else {
        setState(() {
          noMoreProducts = true;
        });
      }
    } catch (error) {
      dev.log('Failed to fetch next page: $error');
    }
  }

  Future<void> _loadNextRecommendedPage() async {
    setState(() {
      recommendedPage++;
    });
    try {
      List<Product> nextPageProducts = await ProductController.fetchHybridRecommendedProducts(
        page: recommendedPage,
        perPage: itemsPerPage,
        productName: widget.product.productName,
      );

      if (nextPageProducts.isNotEmpty) {
        setState(() {
          recommendedProducts.addAll(nextPageProducts);
        });
      } else {
        setState(() {
          noMoreProducts = true;
        });
      }
    } catch (error) {
      dev.log('Failed to fetch next page: $error');
    }
  }

  Future<void> _toggleFavorite() async {
    if (isFavorite) {
      await FavoritesDatabase.deleteFavorite(widget.product.productid);
      dev.log("Product Deleted From Database");
      // Add a notification
      NotificationModel newNotification = NotificationModel(
        title: 'Favorite Deleted',
        description: 'You deleted ${widget.product.productName} from your favorites',
        date: DateTime.now(),
        userId: user.uid,
        dateTime: DateTime.now(),
        productId: widget.product.productid,
        notificationId: Uuid().v4()
      );
      await firebaseService.addNotification(newNotification);
    } else {
      await FavoritesDatabase.insertFavorite(widget.product);
      dev.log("Product Added To Database");
      NotificationModel newNotification = NotificationModel(
        title: 'Favorite Added',
        description: 'You Added ${widget.product.productName} to your favorites',
        date: DateTime.now(),
        userId: user.uid,
        dateTime: DateTime.now(),
        productId: widget.product.productid,
        notificationId: Uuid().v4()
      );
      await firebaseService.addNotification(newNotification);
    }
    showRatingDialogue();
    _checkFavoriteStatus();
  }

  void showRatingDialogue(){
    showDialog(
      context: context,
      builder: (BuildContext context) {
        double userRating = 0.0;
        String userReview = '';

        return AlertDialog(
          title: const Text('Rate and Review' ),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          backgroundColor: Theme.of(context).colorScheme.tertiary,
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RatingBar(
                  initialRating: 0,
                  direction: Axis.horizontal,
                  allowHalfRating: true,
                  itemCount: 5,
                  itemSize: 35.0,
                  itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
                  ratingWidget: RatingWidget(
                    full: const Icon(Icons.star, color: AppColors.purpleLight),
                    half: const Icon(Icons.star_half, color: AppColors.purpleLight),
                    empty: const Icon(Icons.star_border, color: AppColors.purpleLight),
                  ),
                  onRatingUpdate: (rating) {
                    userRating = rating;
                  },
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: TextFormField(
                    onChanged: (value){
                      userReview = value;
                    },
                    style:  TextStyle(
                      color: Theme.of(context).colorScheme.secondary,
                    ),
                    cursorColor: const Color(0xFFA26FFD),
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.transparent),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.purpleAccent),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      hintText: "Write Review Here...",
                      hintStyle: const TextStyle(
                        color: Colors.grey,
                      ),
                      fillColor: Theme.of(context).colorScheme.background,
                      filled: true,
                    ),
                  ),
                )
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text('Cancel', style: TextStyle(color: Colors.red),),
            ),
            TextButton(
              onPressed: () async {
                final user = FirebaseAuth.instance.currentUser!;

                Helpers().submitRating(
                    rating: userRating,
                    review: userReview,
                    userId: user.uid,
                    productId: widget.product.productid.toString()
                );

                var snackBar =
                CustomSnackBar(text: "Thank You For Rating This Product", color: Colors.green, fontSize: 13,);
                ScaffoldMessenger.of(context).showSnackBar(snackBar);

                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text('Submit', style: TextStyle(color: AppColors.purpleLight),),
            ),
          ],
        );
      },
    );
  }
}
