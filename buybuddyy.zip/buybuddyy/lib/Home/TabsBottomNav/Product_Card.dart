import 'dart:math';
import 'package:buybuddyy/Home/TabsBottomNav/Product_details.dart';
import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import '../../Helpers/PlaceHolderImage.dart';
import '../../Helpers/Product_Model.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final int index;

  const ProductCard({super.key, required this.product, required this.index});

  double randomHeight() {
    double minHeight = 150.0;
    double maxHeight = 280.0;
    double randomHeight = minHeight + Random().nextDouble() * (maxHeight - minHeight);
    return randomHeight;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
      ),
      color: Theme.of(context).colorScheme.tertiary,
      child: AnimationConfiguration.staggeredGrid(
        position: index,
        duration: const Duration(milliseconds: 375),
        columnCount: 2,
        child: ScaleAnimation(
          child: GestureDetector(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => ProductDetailsPage(product: product),
                ),
              );
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(8), topRight: Radius.circular(8)),
                  child: Image.network(
                    product.productImage,
                    filterQuality: FilterQuality.high,
                    fit: BoxFit.fitHeight,
                    height: randomHeight(),
                    errorBuilder: (context, error, stackTrace) {
                      return const PlaceholderImageWidget();
                    },
                    loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                      if (loadingProgress == null) {
                        return child;
                      } else {
                        return Shimmer.fromColors(
                          baseColor: Colors.grey[300]!,
                          highlightColor: Colors.grey[100]!,
                          child: Container(
                            color: Colors.white,
                            height: 260,
                          ),
                        );
                      }
                    },
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 4.0),
                      Text(
                        product.productName,
                        style:  TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.secondary),
                      ),
                      const SizedBox(height: 4.0),
                      if(product.productPrice == 0.0)
                         Text(
                          'Coming Soon', // Assuming productPrice is a double
                          style:  TextStyle(color: Theme.of(context).colorScheme.primary),
                        ),
                      if(product.productPrice != 0.0)
                      Text(
                        'Rs ${NumberFormat('#,##0').format(product.productPrice)}', // Assuming productPrice is a double
                        style:   TextStyle(color: Theme.of(context).colorScheme.primary),
                      ),
                      const SizedBox(height: 4.0),
                      Text(
                        'Store: ${product.productStore}',
                        style:  TextStyle(color: Theme.of(context).colorScheme.secondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
