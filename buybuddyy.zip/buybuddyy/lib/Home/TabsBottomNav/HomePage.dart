import 'dart:developer' as dev;
import 'package:buybuddyy/Helpers/helpers.dart';
import 'package:buybuddyy/Home/FavoritesPage.dart';
import 'package:buybuddyy/Home/NotificaitonScreen.dart';
import 'package:buybuddyy/Pages/FilterBottomSheet.dart';
import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Helpers/Product_Controller.dart';
import '../../Helpers/Product_Model.dart';
import '../../Helpers/TagsFilter.dart';
import '../../Helpers/userData.dart';
import '../../Widgets/CustomAppbar.dart';
import '../../Widgets/CustomSearchBar.dart';
import 'Product_Card.dart';
import 'RecommendedProductCard.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final user = FirebaseAuth.instance.currentUser!;

  bool isLoading = false;
  String userName = "";
  String imageUrl = "";
  String searchQuery = "";
  int currentPage = 1;
  int recommendedPage = 1;
  int itemsPerPage = 10;
  bool hasMoreProducts = true;
  List<Product> products = [];
  List<String> allTags = [
    'Laptops',
    'MobilePhones',
    'Apple',
    'Tablets',
    'Smart-Watches',
    'Airpods',
    'Earbuds',
    'Samsung',
    'Gaming'
  ];
  List<String> selectedTags = [];
  List<String> selectedCategories = [];
  List<Product> filteredProductList = [];
  final ScrollController _scrollController = ScrollController();
  final ScrollController _scrollControllerRecommended = ScrollController();
  List<Product> allRecommendedProducts = [];
  Map<String, dynamic>? selectedFilters;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fetchProducts();
    getUserData();

    _scrollController.addListener(() {
      if (_scrollController.position.pixels == _scrollController.position.maxScrollExtent) {
        // User has reached the end of the list, load the next page
        _loadNextPage();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: CustomAppBar(
        name: userName,
        imageUrl: imageUrl,
        onTap: () {},
        actions: [
          IconButton(
            icon:  Icon(Icons.notifications, color: Theme.of(context).colorScheme.secondary,),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return const NotificationScreen();
                  },
                ),
              );
            },
          ),
        ],
      ),
      body: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 8,
                ),
                DynamicSearchBar(
                  hint: "Search",
                  onChanged: (value) {
                    setState(() {
                      updateSearchQuery(value);
                    });
                  },
                  onSubmitted: (value) {},
                ),
                const SizedBox(
                  height: 8,
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.menu),
                      color: Theme.of(context).colorScheme.secondary,
                      onPressed: () {
                        _showBottomSheet(context);
                      },
                    ),
                    Expanded(
                      child: TagsFilter(
                        tags: allTags,
                        selectedTags: selectedTags,
                        onTagSelected: (tag) {
                          if (selectedTags.contains(tag)) {
                            setState(() {
                              selectedTags.remove(tag);
                            });
                          } else {
                            setState(() {
                              selectedTags.add(tag);
                            });
                          }
                          setState(() {
                            _updateProducts();
                          });
                        },
                      ),
                    ),
                  ],
                ),
                if (searchQuery.isNotEmpty)
                   Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 15),
                    child: Text("Recommended Based On Search",
                        style: TextStyle(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.bold, fontSize: 18)),
                  ),
              ],
            ),
          ),
          SliverStaggeredGrid.countBuilder(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            itemCount: filteredProductList.length + (searchQuery.isNotEmpty ? 1 : 0),
            itemBuilder: (context, index) {
              if (index == 0 && searchQuery.isNotEmpty) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildRecommendedProducts(),
                     Padding(
                      padding: const EdgeInsets.only(left: 12.0, right: 12.0),
                      child: Divider(
                        color: Theme.of(context).colorScheme.tertiary,
                      ),
                    ),
                     Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
                      child: Text("Search Results",
                          style: TextStyle(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.bold, fontSize: 18)),
                    ),
                  ],
                );
              } else {
                int adjustedIndex = index - (searchQuery.isNotEmpty ? 1 : 0);

                if (adjustedIndex >= 0 && adjustedIndex < filteredProductList.length) {
                  Product product = filteredProductList[adjustedIndex];
                  return ProductCard(product: product, index: adjustedIndex);
                } else if (adjustedIndex == filteredProductList.length && !isLoading && hasMoreProducts) {
                  return const SizedBox.shrink(); // Empty placeholder for the last item
                } else {
                  if (adjustedIndex == filteredProductList.length) {
                    // Display the recommended products section
                    return const Padding(
                      padding: EdgeInsets.only(bottom: 60.0),
                      child: CupertinoActivityIndicator(color: AppColors.textGreyColor2, radius: 15),
                    );
                  } else {
                    // Display a loading indicator while more products are being fetched
                    return const CircularProgressIndicator(color: AppColors.purpleLight);
                  }
                }
              }
            },
            staggeredTileBuilder: (index) {
              if (index == 0 && searchQuery.isNotEmpty) {
                return const StaggeredTile.fit(2); // StaggeredTile for the recommended products section
              } else {
                return const StaggeredTile.fit(1); // StaggeredTile for regular products
              }
            },
          ),
        ],
      ),
    );
  }

  // ****************************  FUNCTIONS ***************************************

  void _loadNextRecommendedPage() async {
    try {
      List<Product> nextPageProducts = await ProductController.fetchRecommendedProducts(
        productName: searchQuery,
        page: recommendedPage + 1,
      );

      if (nextPageProducts.isNotEmpty) {
        setState(() {
          allRecommendedProducts.addAll(nextPageProducts);
          recommendedPage++;
        });
      }
    } catch (error) {
      dev.log('Failed to load next recommended page: $error');
    }
  }

  Widget _buildRecommendedProducts() {
    return SizedBox(
      height: 220,
      width: double.infinity,
      child: NotificationListener<ScrollNotification>(
        onNotification: (ScrollNotification scrollInfo) {
          if (scrollInfo is ScrollEndNotification &&
              _scrollControllerRecommended.position.extentAfter == 0) {
            _loadNextRecommendedPage();
          }
          return true;
        },
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: allRecommendedProducts.length + 1,
          controller: _scrollControllerRecommended,
          itemBuilder: (context, index) {
            if (index < allRecommendedProducts.length) {
              Product product = allRecommendedProducts[index];
              return RecommendedProductCard(product: product);
            } else {
              // Show loading indicator at the end of the list
              return _buildLoadingIndicator();
            }
          },
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return isLoading
        ? const Padding(
      padding: EdgeInsets.only(bottom: 60.0),
      child: CupertinoActivityIndicator(
        color: AppColors.textGreyColor2,
        radius: 15,
      ),
    )
        : const SizedBox.shrink();
  }

  void getUserData() async {
    final userData = UserData(await SharedPreferences.getInstance());
    setState(() {
      userName = userData.username;
      imageUrl = userData.profilePicUrl;
    });
  }

  void _updateProducts() async {
    setState(() {
      currentPage = 1;
    });

      List<Product> updatedProducts;
      List<Product> recommendProducts = [];
    String? selectedPriceRange = '';
    List<String>? selectedStores = [];

    // Extract selected filters
    if(selectedFilters != null){
      selectedPriceRange = selectedFilters?['selectedPriceRange'];
      selectedStores = selectedFilters?['selectedStores'];
    }
      String storeName = '';
      if(selectedStores != null){
        storeName = selectedStores.join(",");
      }

      recommendProducts = await ProductController.fetchRecommendedProducts(productName: searchQuery, page: recommendedPage);
      allRecommendedProducts.addAll(recommendProducts);

      if (searchQuery.isNotEmpty || selectedTags.isNotEmpty || selectedStores!.isNotEmpty || selectedPriceRange!.isNotEmpty) {
        updatedProducts = await ProductController.searchProducts(
          productName: searchQuery,
          maxPrice: Helpers().extractMaxPrice(selectedPriceRange),
          minPrice: Helpers().extractMinPrice(selectedPriceRange),
          store: storeName,
          isCompare: false,
          tags: selectedTags,
          page: currentPage,
          perPage: itemsPerPage,
        );
      } else {
        updatedProducts = await ProductController.fetchTopRatedProducts(
          page: currentPage,
          perPage: itemsPerPage,
        );
      }

      if (updatedProducts.isNotEmpty) {
        setState(() {
          products = updatedProducts;
          filteredProductList = products;
        });
      } else {
        setState(() {
          hasMoreProducts = false;
        });
      }

  }

  Future<void> updateSearchQuery(String query) async {
    setState(() {
      searchQuery = query.toLowerCase();
    });
    allRecommendedProducts = [];
    _updateProducts();
  }

  Future<void> _fetchProducts() async {
    setState(() {
      currentPage = 1;
    });
    try {
      List<Product> fetchedProducts = await ProductController.fetchTopRatedProducts(page: currentPage, perPage: itemsPerPage);
      setState(() {
        products = fetchedProducts;
        filteredProductList = products;
      });
    } catch (error) {
      // Handle errors
      dev.log('Failed to fetch products: $error');
    }
  }

  Future<void> _loadNextPage() async {
    if (!isLoading) {
      setState(() {
        isLoading = true;
        currentPage++;
      });
      try {
        List<Product> nextPageProducts;

        String? selectedPriceRange = '';
        List<String>? selectedStores = [];

        // Extract selected filters
        if(selectedFilters != null){
          selectedPriceRange = selectedFilters?['selectedPriceRange'];
          selectedStores = selectedFilters?['selectedStores'];
        }

        String storeName = '';
        if(selectedStores != null){
          storeName = selectedStores.join(",");
        }

        if (searchQuery.isNotEmpty || selectedTags.isNotEmpty || selectedStores!.isNotEmpty  || selectedPriceRange!.isNotEmpty) {
          nextPageProducts = await ProductController.searchProducts(
            productName: searchQuery,
            maxPrice: Helpers().extractMaxPrice(selectedPriceRange),
            minPrice: Helpers().extractMinPrice(selectedPriceRange),
            store: storeName,
            isCompare: false,
            tags: selectedTags,
            page: currentPage,
            perPage: itemsPerPage,
          );
        }  else {
          // If not searching, load the next page of regular products
          nextPageProducts = await ProductController.fetchTopRatedProducts(
            page: currentPage,
            perPage: itemsPerPage,
          );
        }

        if (nextPageProducts.isNotEmpty) {
          // If there are products on the next page, append them
          setState(() {
            products.addAll(nextPageProducts);
            filteredProductList.addAll(nextPageProducts); // Append new products to the existing list

          });
        } else {
          // If nextPageProducts is empty, set hasMorePages to false
          setState(() {
            hasMoreProducts = false;
          });
        }
      } catch (error) {
        dev.log('Failed to load next page: $error');
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (BuildContext context) {
        return FilterBottomSheet(onApplyFilter: (filters){
          setState(() {
            selectedFilters = filters;
            _updateProducts();
          });
        }, selectedFilters: selectedFilters
        );
      },
    );
  }
}
