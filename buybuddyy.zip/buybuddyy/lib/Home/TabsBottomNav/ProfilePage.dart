import 'dart:developer';
import 'package:buybuddyy/Helpers/userData.dart';
import 'package:buybuddyy/Home/UpdateProfilePage.dart';
import 'package:buybuddyy/Pages/AboutPage.dart';
import 'package:buybuddyy/Pages/AppearancePage.dart';
import 'package:buybuddyy/Pages/HelpAndSupportPage.dart';
import 'package:buybuddyy/Pages/NotificationsPage.dart';
import 'package:buybuddyy/Pages/PrivacyAndSecurity.dart';
import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:buybuddyy/Widgets/ThemeProvider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Register/SignInScreen.dart';
import '../../Widgets/CustomSearchBar.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  bool isLoading = false;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool isDarkMode = false;

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    final userData = UserData(await SharedPreferences.getInstance());
    userData.clearUserData();

    setState(() {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const SignInScreen()),
            (route) => false,
      );
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        elevation: 0.0,
        automaticallyImplyLeading: false,
        centerTitle: true,
        title:  Text("Settings", style: TextStyle(color: Theme.of(context).colorScheme.secondary),),
        backgroundColor: Theme.of(context).colorScheme.background,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 20,
            ),

            DynamicSearchBar(
              hint: "Search for a setting...",
              onChanged: (value) {
                // Handle search text changes here
                log('Search text changed: $value');

              },
              onSubmitted: (value) {

              },
            ),

            const SizedBox(
              height: 20,
            ),


             FractionallySizedBox(
              alignment: Alignment.topLeft,
              widthFactor: 0.9,
              child: Text(
                "Account",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                  color: Theme.of(context).colorScheme.secondary,
                ),
              ),
            ),
            const SizedBox(
              height: 21,
            ),
            FractionallySizedBox(
              alignment: Alignment.topLeft,
              widthFactor: 0.9,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: Column(
                  children: [
                    InkWell(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              //Sign Up Here
                              return const UpdateProfilePage();
                            },
                          ),
                        );
                      },
                      child:  Row(
                        children: [
                          const Icon(
                            Icons.person_2_outlined,
                            color: AppColors.purpleLight,
                          ),
                          const SizedBox(
                            width: 11,
                          ),
                          Text(
                            "Edit Profile",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          const Spacer(),
                          const FractionallySizedBox(
                            alignment: Alignment.topRight,
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: AppColors.greyIconColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 21,
                    ),

                  ],
                ),
              ),
            ),


            const SizedBox(
              height: 21,
            ),
            //loadCoachSettings(),
            const SizedBox(
              height: 21,
            ),

             FractionallySizedBox(
              alignment: Alignment.topLeft,
              widthFactor: 0.9,
              child: Text(
                "Settings",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                  color: Theme.of(context).colorScheme.secondary,
                ),
              ),
            ),

            const SizedBox(
              height: 21,
            ),

            FractionallySizedBox(
              alignment: Alignment.topLeft,
              widthFactor: 0.9,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child:  Column(
                  children: [
                    InkWell(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              //Sign Up Here
                              return const AppearancePage();
                            },
                          ),
                        );
                      },
                      child: Row(
                        children: [
                          const Icon(
                            Icons.remove_red_eye_outlined,
                            color: AppColors.purpleLight,
                          ),
                          const SizedBox(
                            width: 11,
                          ),
                           Text(
                            "Appearance",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          const Spacer(),


                          const FractionallySizedBox(
                            alignment: Alignment.topRight,
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: AppColors.greyIconColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 21,
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              //Sign Up Here
                              return const HelpAndSupport();
                            },
                          ),
                        );
                      },
                      child:  Row(
                        children: [
                          const Icon(
                            Icons.headphones,
                            color: AppColors.purpleLight,
                          ),
                          const SizedBox(
                            width: 11,
                          ),
                          Text(
                            "Help & Support",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          const Spacer(),
                          const FractionallySizedBox(
                            alignment: Alignment.topRight,
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: AppColors.greyIconColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 21,
                    ),
                     InkWell(
                       onTap: (){
                         Navigator.push(
                           context,
                           MaterialPageRoute(
                             builder: (context) {
                               //Sign Up Here
                               return const AboutPage();
                             },
                           ),
                         );
                       },
                       child:  Row(
                        children: [
                          const Icon(
                            Icons.help_outline_sharp,
                            color: AppColors.purpleLight,
                          ),
                          const SizedBox(
                            width: 11,
                          ),
                          Text(
                            "About",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          const Spacer(),
                          const FractionallySizedBox(
                            alignment: Alignment.topRight,
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: AppColors.greyIconColor,
                            ),
                          ),
                        ],
                    ),
                     ),
                    const SizedBox(
                      height: 21,
                    ),
                    InkWell(
                      onTap: signOut,
                      child:  Row(
                        children: [
                          const Icon(
                            Icons.logout_rounded,
                            color: AppColors.purpleLight,
                          ),
                          const SizedBox(
                            width: 11,
                          ),
                          Text(
                            "Logout",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Theme.of(context).colorScheme.secondary,
                            ),
                          ),
                          const Spacer(),
                          // FractionallySizedBox(
                          //   alignment: Alignment.topRight,
                          //   child: Icon(
                          //     Icons.arrow_forward_ios,
                          //     color: AppColors.greyIconColor,
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
