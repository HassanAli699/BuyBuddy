import 'dart:developer';

import 'package:buybuddyy/Widgets/Colors.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Helpers/userData.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import '../Widgets/CustomSnackBar.dart';

class UpdateProfilePage extends StatefulWidget {
  const UpdateProfilePage({super.key});

  @override
  State<UpdateProfilePage> createState() => _UpdateProfilePageState();
}

class _UpdateProfilePageState extends State<UpdateProfilePage> {

  String userName ='';
  String imageUrl = '';
  String email = '';
  String phoneNo ='';
  bool isLoading = false;
  String imageUrlFromFirebase = '';
  String greyText = "#333333".replaceAll("#", "0xff");
   TextEditingController _emailController = TextEditingController();
   TextEditingController _phoneNoController = TextEditingController();
   TextEditingController _userNameController = TextEditingController();
  final picker = ImagePicker();

  void getProfileDetails() async {
    _emailController = TextEditingController(text: email);
    _phoneNoController = TextEditingController(text: phoneNo);
    _userNameController = TextEditingController(text: userName);
  }

  Future<void> getUserData() async {
    final userData = UserData(await SharedPreferences.getInstance());
    setState(() {
      userName = userData.username;
      imageUrl = userData.profilePicUrl;
      email = userData.email;
      phoneNo = userData.phoneNumber;
    });
  }

  Future<void> updateUserData(String newEmail, String newPhoneNumber, String userName) async {
    setState(() {
      isLoading = true;
    });
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        await user.updateEmail(newEmail);

        FirebaseFirestore.instance.collection('Users').doc(email).update({
          'email': newEmail,
          'phoneNumber': newPhoneNumber,
          'userName': userName
        });

        log('User data updated successfully');

        final UserData userData = UserData(await SharedPreferences.getInstance());

        userData.setEmail(newEmail);
        userData.setPhoneNumber(newPhoneNumber);
        userData.setUsername(userName);

        var snackBar =
        CustomSnackBar(text: "Profile Updated Successfully", color: Colors.green);
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
        setState(() {
          isLoading = false;
        });
      } catch (e) {
        log('Error updating user data: $e');
        var snackBar =
        CustomSnackBar(text: "Login Again and Try Again Please", color: Colors.red);
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
        setState(() {
          isLoading = false;
        });
      }
    } else {
      log('User is not logged in');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> uploadImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final file = File(pickedFile.path);
      final storageRef = FirebaseStorage.instance.ref().child('ProfileImages').child('profile.jpg');
      final uploadTask = storageRef.putFile(file);

      final snapshot = await uploadTask.whenComplete(() {});
      if (snapshot.state == TaskState.success) {
        final imageUrl = await snapshot.ref.getDownloadURL();

        // Update the image URL in Firestore
        final userDocRef = FirebaseFirestore.instance.collection('Users').doc(email);
        await userDocRef.update({'profilePicUrl': imageUrl});

        // Refresh the UI with the new image
        setState(() {
          imageUrlFromFirebase = imageUrl;
        });

        log('Image uploaded successfully!');
        var snackBar =
        CustomSnackBar(text: "Profile Image Updated", color: Colors.green);
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
       final UserData userData = UserData(await SharedPreferences.getInstance());
       setState(() {
         userData.setProfilePicUrl(imageUrl);
       });

      } else {
        log('Error uploading image');
      }
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserData().then((value) => {
      getProfileDetails()
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        elevation: 0.0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon:  Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).colorScheme.secondary,
          ),
        ),
        title:  Text("Update Profile", style: TextStyle(color: Theme.of(context).colorScheme.secondary),),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.background,
      ),
      body: Column(
        children: [
          Center(
            child: Stack(
              children: [
                Container(
                  width: 130,
                  height: 130,
                  decoration: BoxDecoration(
                    border: Border.all(width: 0, color: Colors.transparent),
                    boxShadow: [
                      BoxShadow(
                          spreadRadius: 2,
                          blurRadius: 10,
                          color: Colors.black.withOpacity(0.1)),
                    ],
                    shape: BoxShape.circle,
                    image:  DecorationImage(
                      fit: BoxFit.cover,
                      image: imageUrl.isNotEmpty
                          ? NetworkImage(imageUrl)
                          : const AssetImage('lib/Assets/placeholder.png') as  ImageProvider<Object>,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: GestureDetector(
                    onTap: uploadImage,
                    child: Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 0,
                          color: Colors.transparent,
                        ),
                        color: Theme.of(context).colorScheme.tertiary,
                      ),
                      child:  Icon(
                        Icons.camera_alt_outlined,
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30,),

          loadTextFields("Your Email", Icons.email, _emailController),
          const SizedBox(height: 16,),
          loadTextFields("Your Name", Icons.person, _userNameController),
          const SizedBox(height: 16,),
          loadTextFields("Phone number", Icons.phone, _phoneNoController),

         const Spacer(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child:GestureDetector(
              onTap: (){
                updateUserData(_emailController.text.trim(), _phoneNoController.text.trim(), _userNameController.text.trim());
              },
              child: Container(
                height: 50,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFFA26FFD),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child:Center(
                        child: isLoading ?  const SpinKitThreeBounce(
                          color: Colors.white,
                          size: 20.0,
                        )  : const Text(
                          'Update Profile',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 16,),

        ],
      ),
    );
  }

  loadTextFields(
      String hint, IconData iconData, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        style:  TextStyle(
          color: Theme.of(context).colorScheme.secondary,
        ),
        controller: Controller,
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon: Icon(
            iconData,
            color: Theme.of(context).colorScheme.primary,
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: Theme.of(context).colorScheme.tertiary,
          filled: true,
        ),
      ),
    );
  }



}//end
