import 'dart:developer';

import 'package:buybuddyy/Helpers/helpers.dart';
import 'package:buybuddyy/Register/SignInScreen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:uuid/uuid.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {


  String color = "#252525".replaceAll('#', '0xff');
  String greyText = "#333333".replaceAll("#", "0xff");
  bool obscureText = true;
  bool isLoading = false;

  final TextEditingController _userNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();

  Future<void> _signUp() async {
    setState(() {
      isLoading = true;
    });

    try {
      UserCredential userCredential =
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );


      // Save user details in FireStore database
      await FirebaseFirestore.instance
          .collection('Users')
          .doc(_emailController.text.trim())
          .set({
        'userName': _userNameController.text.trim(),
        'email': _emailController.text.trim(),
        'phoneNumber': _phoneNumberController.text.trim(),
        'profilePicUrl':''
      });

      setState(() {
        isLoading = false;
      });

      setState(() {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Congratulation!'),
              content: const Text('You are Successfully Signed up Please Login to Continue'),
              actions: <Widget>[
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return const SignInScreen();
                        },
                      ),
                    );
                  },
                ),
              ],
            );
          },
        );
      });

    } on FirebaseAuthException catch (e) {
      String errorMessage = 'Sign up failed. Please try again later.';
      setState(() {
        isLoading = false;
      });
      if (e.code == 'email-already-in-use') {
        errorMessage = 'This email is already in use.';
        setState(() {
          isLoading = false;
        });
      } else if (e.code == 'weak-password') {
        errorMessage = 'The password provided is too weak.';
        setState(() {
          isLoading = false;
        });
      }
      setState(() {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Error'),
              content: Text(errorMessage),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
      });

    } catch (e) {
      log(e.toString());
    }
  }

  loadTextFields(String hint, IconData iconData, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        style: const TextStyle(
          color: Colors.white,
        ),
        controller: Controller,
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon:  Icon(
            iconData,
            color: const Color(0xFFBDBDBD),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide:
            const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
                color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: Color(int.parse(greyText)),
          filled: true,
        ),
      ),
    );
  }

  loadPasswordTextFields(String hint, IconData iconData, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        obscureText: obscureText,
        style: const TextStyle(
          color: Colors.white,
        ),
        controller: Controller,
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon:  Icon(
            iconData,
            color: const Color(0xFFBDBDBD),
          ),
          suffixIcon:  GestureDetector(
            onTap: (){
              setState(() {
                obscureText = !obscureText;
              });
            },
            child:  obscureText
                ? const Icon(
              Icons.visibility_off,
              color: Colors.grey,
            )
                : const Icon(
              Icons.visibility,
              color:  Color(0xFFA26FFD),
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide:
            const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
                color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: Color(int.parse(greyText)),
          filled: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          leading: Navigator.canPop(context) ? IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back_ios),
            //replace with our own icon data.
          ) : Text("")
      ),
      body: SizedBox(
        height: double.infinity,
        width: double.infinity,
        child: Card(
          elevation: 20,
          color: Color(int.parse(color)),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40),
              topRight: Radius.circular(40),
            ),
          ),
          child:  SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40.0),
                  child: Text(
                    "Sign up and start exploring",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 16,
                ),

                loadTextFields("Your Name", Icons.person, _userNameController),

                const SizedBox(
                  height: 16,
                ),

                loadTextFields("Email Address", Icons.mail, _emailController),

                const SizedBox(
                  height: 16,
                ),

                loadTextFields("Phone number", Icons.phone, _phoneNumberController),

                const SizedBox(
                  height: 16,
                ),

                loadPasswordTextFields("Password", Icons.lock, _passwordController),

                const SizedBox(
                  height: 16,
                ),

                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15.0),
                  child: Row(
                    children: [
                      Text(
                        "By signing up you agree to our ",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                      Text(
                        " Terms of Use",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        " and ",
                        style: TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                      Text(
                        "Privacy Notice",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20,),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child:GestureDetector(
                    onTap: _signUp,
                    child: Container(
                      height: 50,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFFA26FFD),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child:Center(
                      child: isLoading ?  const SpinKitThreeBounce(
                        color: Colors.white,
                        size: 20.0,
                      )  : const Text(
                              'Sign Up Now',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20,),

                FractionallySizedBox(
                  alignment: Alignment.center,
                  widthFactor: 0.5,
                  child: Row(
                    children: [
                       const Text(
                        "Already registered? ",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey, fontSize: 14),
                      ),
                      GestureDetector(
                        onTap: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return const SignInScreen();
                              },
                            ),
                          );
                        },
                        child: const Text(
                          " Sign In",
                          style: TextStyle(
                            color: Color(0xFFA26FFD),
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),



              ],
            ),
          ),
        ),

      ),
    );
  }
}
