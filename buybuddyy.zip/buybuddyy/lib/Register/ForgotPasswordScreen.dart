import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import '../Widgets/CustomSnackBar.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final TextEditingController _emailController = TextEditingController();
  bool isLoading = false;
  String color = "#252525".replaceAll('#', '0xff');
  String greyText = "#333333".replaceAll("#", "0xff");
  String newgrey = '#787878'.replaceAll("#", "0xff");
  bool obscureText = true;
  bool isCheckedRememberMe = false;

  loadTextFields(
      String hint, IconData iconData, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        style: const TextStyle(
          color: Colors.white,
        ),
        controller: Controller,
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon: Icon(
            iconData,
            color: const Color(0xFFBDBDBD),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: Color(int.parse(greyText)),
          filled: true,
        ),
      ),
    );
  }

  Future<void> resetPassword(String email) async {
    try {
      setState(() {
        isLoading = true;
      });
      await FirebaseAuth.instance
          .sendPasswordResetEmail(email: email)
          .then((value) => {
                setState(() {
                  isLoading = false;
                  log('Password reset email sent to $email');
                  var snackBar = CustomSnackBar(
                      text: "Password Reset Email Sent", color: Colors.green);
                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                })
              });
      // Show success message or navigate to a success screen
    } catch (error) {
      // Show error message or handle the error
      log('Password reset failed: $error');
      setState(() {
        isLoading = false;
      });
      var snackBar =
          CustomSnackBar(text: "Cannot Reset Password", color: Colors.red);
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back_ios),
            //replace with our own icon data.
          )),
      body: SizedBox(
        height: double.infinity,
        width: double.infinity,
        child: Card(
          elevation: 20,
          color: Color(int.parse(color)),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40),
              topRight: Radius.circular(40),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 50.0),
                  child: Text(
                    "Forgot Your Password ?",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                const Text(
                  "Enter your email below to reset your password",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                loadTextFields("Your Email", Icons.email, _emailController),
                const SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: GestureDetector(
                    onTap: () {
                      resetPassword(_emailController.text.trim());
                    },
                    child: Container(
                      height: 50,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFFA26FFD),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Center(
                              child: isLoading
                                  ? const SpinKitThreeBounce(
                                      color: Colors.white,
                                      size: 20.0,
                                    )
                                  : const Text(
                                      'Reset Password',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
