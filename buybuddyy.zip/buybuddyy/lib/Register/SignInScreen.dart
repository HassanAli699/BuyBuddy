import 'dart:developer';
import 'package:buybuddyy/Home/HomeScreen.dart';
import 'package:buybuddyy/Register/ForgotPasswordScreen.dart';
import 'package:buybuddyy/Register/signUpScreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Helpers/helpers.dart';
import '../Widgets/CustomSnackBar.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({Key? key}) : super(key: key);

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {

  String color = "#252525".replaceAll('#', '0xff');
  String greyText = "#333333".replaceAll("#", "0xff");
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  bool obscureText = true;
  bool _rememberMe = false;
  bool isLoading = false;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<bool> signInWithGoogle() async {
    setState(() {
      isLoading = true;
    });
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

    if (googleUser != null) {
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        idToken: googleAuth.idToken,
        accessToken: googleAuth.accessToken,
      );

      List<String> authProviders = await _auth.fetchSignInMethodsForEmail(googleUser.email);

      if (authProviders.contains("password")) {
        _googleSignIn.signOut();
        var snackBar =
        CustomSnackBar(text: "Please Login with Email and Password", color: Colors.redAccent, fontSize: 12,);
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
        return false;
      } else{
        bool userExists = await Helpers().checkUserExists(googleUser);
        if(userExists){

          final UserCredential userCredential =
          await _auth.signInWithCredential(credential);
          log("USER EMAIL ::${userCredential.user?.email}");
          log("USER NAME :: ${userCredential.user?.displayName}");
          log("PHOTO URL :: ${userCredential.user?.photoURL}");

          Map<String, dynamic> userData = await Helpers().getUserDataFromFireStore(googleUser.email);
          await Helpers().saveUserToSharedPreferences(userData);

          setState(() {
            isLoading = false;
          });
          return true;
        }else{
          setState(() {
            isLoading = false;
          });
          _googleSignIn.signOut();
          var snackBar =
          CustomSnackBar(text: "Please Sign Up Before Logging In", color: Colors.redAccent);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
          return false;
        }
      }



    }

    throw Exception('Google Sign-In was canceled.');
  }

  Future<void> _login() async {
    setState(() {
      isLoading = true;
    });
    String email = _emailController.text.trim();
    String password = _passwordController.text.trim();

    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      setState(() {
        isLoading = false;
      });

      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('rememberMe', _rememberMe);

      Map<String, dynamic> userData = await Helpers().getUserDataFromFireStore(email);
      await Helpers().saveUserToSharedPreferences(userData);

      var snackBar =
      CustomSnackBar(text: "Login Successfully", color: Colors.green);
      ScaffoldMessenger.of(context).showSnackBar(snackBar);

      // Login successful, navigate to the next screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) {
            return const HomeScreen();
          },
        ),
      );




    } on FirebaseAuthException catch (e) {
      // Handle login errors
      String errorMessage = 'Login failed. Please try again later.';
      setState(() {
        isLoading = false;
      });
      if (e.code == 'user-not-found') {
        errorMessage = 'User not found.';
        setState(() {
          isLoading = false;
        });
      } else if (e.code == 'wrong-password') {
        errorMessage = 'Wrong password.';
        setState(() {
          isLoading = false;
        });
      }
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text(errorMessage),
            actions: <Widget>[
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    } catch (e) {
      print(e.toString());
    }
  }

  loadTextFields(
      String hint, IconData iconData, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        style: const TextStyle(
          color: Colors.white,
        ),
        controller: Controller,
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon: Icon(
            iconData,
            color: const Color(0xFFBDBDBD),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: Color(int.parse(greyText)),
          filled: true,
        ),
      ),
    );
  }

  loadPasswordTextFields(
      String hint, IconData iconData, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        obscureText: obscureText,
        style: const TextStyle(
          color: Colors.white,
        ),
        controller: Controller,
        cursorColor: const Color(0xFFA26FFD),
        decoration: InputDecoration(
          prefixIcon: Icon(
            iconData,
            color: const Color(0xFFBDBDBD),
          ),
          suffixIcon: GestureDetector(
            onTap: () {
              setState(() {
                obscureText = !obscureText;
              });
            },
            child: obscureText
                ? const Icon(
                    Icons.visibility_off,
                    color: Color(0xFFBDBDBD),
                  )
                : const Icon(
                    Icons.visibility,
                    color: Color(0xFFA26FFD),
                  ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.purpleAccent),
            borderRadius: BorderRadius.circular(15),
          ),
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          fillColor: Color(int.parse(greyText)),
          filled: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          leading: Navigator.canPop(context) ? IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back_ios),
            //replace with our own icon data.
          ) : Text("")
      ),
      body: SizedBox(
        height: double.infinity,
        width: double.infinity,
        child: Card(
          elevation: 20,
          color: Color(int.parse(color)),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40),
              topRight: Radius.circular(40),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 100.0),
                  child: Text(
                    "Glad to meet you again!",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                loadTextFields("Your Email", Icons.email, _emailController),
                const SizedBox(
                  height: 16,
                ),
                loadPasswordTextFields(
                    "Password", Icons.lock, _passwordController),
                const SizedBox(
                  height: 16,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 15.0,
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                                height: 24.0,
                                width: 24.0,
                                child: Theme(
                                  data: ThemeData(
                                      unselectedWidgetColor:
                                          const Color(0xFFA26FFD)),
                                  child: Checkbox(
                                      activeColor: const Color(0xFFA26FFD),
                                      value: _rememberMe,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(5)),
                                      onChanged: (value) {
                                        setState(() {
                                          _rememberMe = value!;
                                          log("Is user to remember : $_rememberMe");
                                          //False for unselect and true for select.
                                        });
                                      }),
                                )),
                            const SizedBox(width: 2.0),
                            const Text("Remember Me",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ))
                          ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 15.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          GestureDetector(
                            child: const Text(
                              "Forgot Password",
                              textAlign: TextAlign.end,
                              style: TextStyle(
                                  color: Colors.white, fontSize: 13.5),
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) {
                                    return const ForgotPasswordPage();
                                  },
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: GestureDetector(
                    onTap: _login,
                    child: Container(
                      height: 50,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFFA26FFD),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Center(
                              child: isLoading
                                  ? const SpinKitThreeBounce(
                                      color: Colors.white,
                                      size: 20.0,
                                    )
                                  : const Text(
                                      'Login Now',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                const Text(
                  'Or',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                GestureDetector(
                  onTap: () async {
                    bool isSignIn = await signInWithGoogle();
                    if(isSignIn){
                      setState(() {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return const HomeScreen();
                            },
                          ),
                        );
                      });

                    }else{
                      print('Sign-in error');
                      setState(() {
                        isLoading = false;
                      });
                    }

                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      height: 50,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                      Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.2),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Image.asset('lib/Assets/google_logo.png'),
                                  ),
                                ),
                              ),
                          const Expanded(
                            child: Text(
                              'Login with Google',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 31,
                ),
                FractionallySizedBox(
                  alignment: Alignment.center,
                  widthFactor: 0.6,
                  child: Row(
                    children: [
                      const Text(
                        "Don't have an account? ",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey, fontSize: 14),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return const SignUpScreen();
                              },
                            ),
                          );
                        },
                        child: const Text(
                          " Sign Up",
                          style: TextStyle(
                            color: Color(0xFFA26FFD),
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
