import 'dart:developer';
import 'package:buybuddyy/Helpers/helpers.dart';
import 'package:buybuddyy/Home/HomeScreen.dart';
import 'package:buybuddyy/Home/TabsBottomNav/HomePage.dart';
import 'package:buybuddyy/Register/SignInScreen.dart';
import 'package:buybuddyy/Register/signUpScreen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Helpers/userData.dart';
import '../Widgets/Colors.dart';
import '../Widgets/CustomSnackBar.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  bool isLoading = false;
  String userName = '';

  Future<bool> signInWithGoogle() async {
    setState(() {
      isLoading = true;
    });

    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();


      if (googleUser != null) {
        final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

        final AuthCredential credential = GoogleAuthProvider.credential(
          idToken: googleAuth.idToken,
          accessToken: googleAuth.accessToken,
        );

        bool userExists = await Helpers().checkUserExists(googleUser);

        if (userExists) {
          _googleSignIn.signOut();
          setState(() {
            isLoading = false;
          });

          var snackBar = CustomSnackBar(
            text: "This Email is Already in Use. Please Login.",
            fontSize: 12,
            color: Colors.redAccent,
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);

          return false; // User already exists, return null
        } else {
          final UserCredential userCredential = await _auth.signInWithCredential(credential);
          await Helpers().saveUserToDatabase(googleUser, googleAuth);
          Map<String, dynamic> userData = await Helpers().getUserDataFromFireStore(googleUser.email);
          await Helpers().saveUserToSharedPreferences(userData);
          setState(() {
            isLoading = false;
          });
          return true;
        }
      }
    } catch (e) {
      print("Error signing in with Google: $e");
    }

    // If there's an error or Google Sign-In was canceled, return null
    setState(() {
      isLoading = false;
    });
    return false;
  }


  void checkSignIn() async {
    setState(() {
      isLoading = true;
    });

    if (await _googleSignIn.isSignedIn()) {
      setState(() {
        isLoading = false;

        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => const HomeScreen(),
          ),
        );
      });
    } else {
      setState(() {
        isLoading = false;
      });
      return;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkSignIn();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
            backgroundColor: Colors.grey[300],
            body: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(image: AssetImage("lib/Assets/background3.jpg"), fit: BoxFit.cover),
              ),
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.black45, Colors.black54]),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    const Image(
                      image: AssetImage("lib/Assets/logo2.png"),
                      height: 100,
                      width: 100,
                      color: Colors.white,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const Text(
                      'Welcome to BuyBuddy',
                      style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    const Center(
                      child: Text(
                        'Make Your Shopping Easier With Us',
                        style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w400),
                      ),
                    ),
                    const SizedBox(
                      height: 200,
                    ),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return const SignInScreen();
                              },
                            ),
                          );
                        },
                        child: Container(
                          height: 50,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: const Color(0xFFA26FFD),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.email,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                ),
                              ),
                              const Expanded(
                                child: Text(
                                  'Continue with Email',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(
                      height: 5,
                    ),

                    //**** CONTINUE WITH GOOGLE
                    GestureDetector(
                      onTap: () async {
                        bool isSignIn = await signInWithGoogle();
                        if(isSignIn){
                          setState(() {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) {
                                  return const HomeScreen();
                                },
                              ),
                            );
                          });
                        }else{
                          log('Sign-in error');
                          setState(() {
                            isLoading = false;
                          });
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          height: 50,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.2),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Image.asset('lib/Assets/google_logo.png'),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Center(
                                  child: isLoading
                                      ? const SpinKitThreeBounce(
                                          color: AppColors.purpleLight,
                                          size: 20.0,
                                        )
                                      : const Text(
                                          'Continue with Google',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }
}
